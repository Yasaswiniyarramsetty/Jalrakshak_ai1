import { Zone, SensorNode, Incident, AiPrediction, WaterAuditStats, AgentLog } from '../types/pipeline';

export const INITIAL_ZONES: Zone[] = [
  {
    id: 'zone-north',
    name: 'North Transmission Corridor',
    code: 'NTC-01',
    activeLineKm: 284.5,
    nodesCount: 78,
    avgPressure: 5.4,
    status: 'OPTIMAL',
    lossRatePercent: 4.8,
    description: 'High-pressure trunk main delivering potable water from Master Balancing Reservoir to northern district.'
  },
  {
    id: 'zone-south',
    name: 'South Industrial Sector',
    code: 'SIS-02',
    activeLineKm: 196.2,
    nodesCount: 64,
    avgPressure: 4.1,
    status: 'CRITICAL',
    lossRatePercent: 12.6,
    description: 'Heavy industrial consumption zone with ductile iron pipelines subject to cyclic pressure surges.'
  },
  {
    id: 'zone-east',
    name: 'East Commercial Ward',
    code: 'ECW-03',
    activeLineKm: 218.0,
    nodesCount: 52,
    avgPressure: 3.8,
    status: 'ADVISORY',
    lossRatePercent: 8.2,
    description: 'High-density business district with aged cast-iron pipelines and complex distribution valves.'
  },
  {
    id: 'zone-west',
    name: 'West Residential Grid',
    code: 'WRG-04',
    activeLineKm: 143.8,
    nodesCount: 44,
    avgPressure: 3.2,
    status: 'OPTIMAL',
    lossRatePercent: 5.1,
    description: 'Smart metered residential township with HDPE low-pressure reticulation and automated PRVs.'
  }
];

export const INITIAL_NODES: SensorNode[] = [
  {
    id: 'node-n01',
    name: 'MBR Inlet Master Node',
    zoneId: 'zone-north',
    zoneName: 'North Transmission Corridor',
    type: 'MULTI',
    x: 22,
    y: 18,
    depthMeters: 3.2,
    pipeDiameterMm: 900,
    pipeMaterial: 'Mild Steel',
    installationYear: 2018,
    status: 'ONLINE',
    batteryLevel: 98,
    rssi: -64,
    readings: {
      pressureBar: 5.82,
      flowLps: 342.5,
      acousticDb: 18.4,
      ph: 7.35,
      turbidityNtu: 0.82,
      chlorineMgL: 1.45,
      tempC: 21.4
    },
    lastTelemetryTime: 'Just now'
  },
  {
    id: 'node-n02',
    name: 'PRV-Station 04 Bypass',
    zoneId: 'zone-north',
    zoneName: 'North Transmission Corridor',
    type: 'PRESSURE',
    x: 38,
    y: 26,
    depthMeters: 2.8,
    pipeDiameterMm: 600,
    pipeMaterial: 'Ductile Iron',
    installationYear: 2016,
    status: 'ONLINE',
    batteryLevel: 91,
    rssi: -68,
    readings: {
      pressureBar: 5.25,
      flowLps: 210.0,
      acousticDb: 22.1,
      ph: 7.32,
      turbidityNtu: 0.88,
      chlorineMgL: 1.38,
      tempC: 21.8
    },
    lastTelemetryTime: 'Just now'
  },
  {
    id: 'node-s01',
    name: 'Ind-Park Spur Junction',
    zoneId: 'zone-south',
    zoneName: 'South Industrial Sector',
    type: 'ACOUSTIC',
    x: 55,
    y: 68,
    depthMeters: 2.4,
    pipeDiameterMm: 450,
    pipeMaterial: 'Ductile Iron',
    installationYear: 2012,
    status: 'DEGRADED',
    batteryLevel: 62,
    rssi: -82,
    readings: {
      pressureBar: 2.85,
      flowLps: 188.4,
      acousticDb: 64.8, // high acoustic anomaly
      ph: 7.10,
      turbidityNtu: 1.95,
      chlorineMgL: 0.92,
      tempC: 23.1
    },
    lastTelemetryTime: '2s ago'
  },
  {
    id: 'node-s02',
    name: 'Chemical Cluster Main #9',
    zoneId: 'zone-south',
    zoneName: 'South Industrial Sector',
    type: 'MULTI',
    x: 68,
    y: 78,
    depthMeters: 3.5,
    pipeDiameterMm: 500,
    pipeMaterial: 'Pre-stressed Concrete',
    installationYear: 2008,
    status: 'DEGRADED',
    batteryLevel: 74,
    rssi: -76,
    readings: {
      pressureBar: 2.15, // rapid drop
      flowLps: 295.2, // surge indicating rupture downstream
      acousticDb: 78.4, // loud burst hiss
      ph: 6.95,
      turbidityNtu: 3.40,
      chlorineMgL: 0.65,
      tempC: 24.2
    },
    lastTelemetryTime: 'Just now'
  },
  {
    id: 'node-e01',
    name: 'Metro Center Ring Node',
    zoneId: 'zone-east',
    zoneName: 'East Commercial Ward',
    type: 'FLOW',
    x: 72,
    y: 35,
    depthMeters: 4.1,
    pipeDiameterMm: 400,
    pipeMaterial: 'Cast Iron',
    installationYear: 2002,
    status: 'ONLINE',
    batteryLevel: 85,
    rssi: -71,
    readings: {
      pressureBar: 3.92,
      flowLps: 145.0,
      acousticDb: 38.6,
      ph: 7.42,
      turbidityNtu: 1.15,
      chlorineMgL: 1.22,
      tempC: 22.0
    },
    lastTelemetryTime: '3s ago'
  },
  {
    id: 'node-e02',
    name: 'Financial Hub Offtake',
    zoneId: 'zone-east',
    zoneName: 'East Commercial Ward',
    type: 'PRESSURE',
    x: 82,
    y: 46,
    depthMeters: 3.0,
    pipeDiameterMm: 350,
    pipeMaterial: 'Cast Iron',
    installationYear: 1999,
    status: 'ONLINE',
    batteryLevel: 88,
    rssi: -69,
    readings: {
      pressureBar: 3.65,
      flowLps: 98.2,
      acousticDb: 42.1,
      ph: 7.38,
      turbidityNtu: 1.28,
      chlorineMgL: 1.18,
      tempC: 22.5
    },
    lastTelemetryTime: 'Just now'
  },
  {
    id: 'node-w01',
    name: 'Township Booster Node',
    zoneId: 'zone-west',
    zoneName: 'West Residential Grid',
    type: 'MULTI',
    x: 28,
    y: 72,
    depthMeters: 2.1,
    pipeDiameterMm: 300,
    pipeMaterial: 'HDPE',
    installationYear: 2021,
    status: 'ONLINE',
    batteryLevel: 95,
    rssi: -58,
    readings: {
      pressureBar: 3.35,
      flowLps: 84.1,
      acousticDb: 14.2,
      ph: 7.48,
      turbidityNtu: 0.55,
      chlorineMgL: 1.50,
      tempC: 20.9
    },
    lastTelemetryTime: 'Just now'
  },
  {
    id: 'node-w02',
    name: 'Eco-Sector PRV Distribution',
    zoneId: 'zone-west',
    zoneName: 'West Residential Grid',
    type: 'FLOW',
    x: 18,
    y: 84,
    depthMeters: 1.9,
    pipeDiameterMm: 250,
    pipeMaterial: 'HDPE',
    installationYear: 2022,
    status: 'ONLINE',
    batteryLevel: 94,
    rssi: -62,
    readings: {
      pressureBar: 3.12,
      flowLps: 62.4,
      acousticDb: 12.8,
      ph: 7.50,
      turbidityNtu: 0.48,
      chlorineMgL: 1.55,
      tempC: 20.5
    },
    lastTelemetryTime: '1s ago'
  }
];

export const INITIAL_INCIDENTS: Incident[] = [
  {
    id: 'inc-01',
    code: 'INC-2026-0941',
    title: 'Severe Acoustic Anomaly & Pressure Drop: Node S-02',
    zoneId: 'zone-south',
    zoneName: 'South Industrial Sector',
    nodeId: 'node-s02',
    severity: 'P1_CRITICAL',
    type: 'PIPE_BURST',
    status: 'ACTIVE',
    timestamp: '12 mins ago',
    estimatedLossRateLpm: 680,
    aiConfidence: 96.4,
    assignedCrew: 'Rapid Response Unit 4',
    actionsTaken: [
      'AI Agent triggered auto-damping command on Upstream PRV-09',
      'Telemetry correlated acoustic peak (78.4 dB) with flow divergence',
      'SCADA dispatch ticket generated automatically'
    ]
  },
  {
    id: 'inc-02',
    code: 'INC-2026-0938',
    title: 'Micro-leak Signature Detected: Sub-surface Acoustic Waveform',
    zoneId: 'zone-south',
    zoneName: 'South Industrial Sector',
    nodeId: 'node-s01',
    severity: 'P2_HIGH',
    type: 'MICRO_LEAK',
    status: 'CREW_DISPATCHED',
    timestamp: '34 mins ago',
    estimatedLossRateLpm: 120,
    aiConfidence: 89.1,
    assignedCrew: 'Acoustic Correlation Squad 2',
    actionsTaken: [
      'Ground microphone verification team en route',
      'Telemetry alert escalated to District Hydro-Engineer'
    ]
  },
  {
    id: 'inc-03',
    code: 'INC-2026-0925',
    title: 'Water Hammer Transient Spike: Metro Ring Line',
    zoneId: 'zone-east',
    zoneName: 'East Commercial Ward',
    nodeId: 'node-e02',
    severity: 'P3_MODERATE',
    type: 'PRESSURE_TRANSIENT',
    status: 'ACKNOWLEDGED',
    timestamp: '1 hr 12m ago',
    estimatedLossRateLpm: 0,
    aiConfidence: 92.0,
    actionsTaken: [
      'Transient surge relief valve dampener checked',
      'Pump ramping speed recalibrated'
    ]
  }
];

export const INITIAL_PREDICTIONS: AiPrediction[] = [
  {
    id: 'pred-01',
    segmentId: 'SEG-SIS-410',
    segmentName: 'South Industrial Sector Trunk #4',
    zoneName: 'South Industrial Sector',
    burstRiskScore: 92,
    riskLevel: 'EXTREME',
    remainingUsefulLifeMonths: 4,
    degradationRatePercent: 8.4,
    transientVulnerability: 'CRITICAL',
    recommendation: 'Immediate non-destructive CIPP lining or scheduled pipe replacement within 30 days. Restrict peak delivery pressure to 3.8 Bar.',
    primaryStressFactor: 'Soil sulfate corrosion + cyclical pressure water hammer transients from industrial pumps.',
    lastSimulatedHammerBar: 8.4
  },
  {
    id: 'pred-02',
    segmentId: 'SEG-ECW-112',
    segmentName: 'East Commercial Ring Branch 2',
    zoneName: 'East Commercial Ward',
    burstRiskScore: 68,
    riskLevel: 'HIGH',
    remainingUsefulLifeMonths: 14,
    degradationRatePercent: 4.2,
    transientVulnerability: 'ELEVATED',
    recommendation: 'Deploy acoustic hydrophone mesh sensors every 50 meters and reduce night-time distribution pressure by 15%.',
    primaryStressFactor: 'Wall thinning in 27-year-old cast iron pipeline with sub-surface vehicular vibration.',
    lastSimulatedHammerBar: 6.2
  },
  {
    id: 'pred-03',
    segmentId: 'SEG-NTC-088',
    segmentName: 'North Transmission Feeder 1',
    zoneName: 'North Transmission Corridor',
    burstRiskScore: 24,
    riskLevel: 'LOW',
    remainingUsefulLifeMonths: 96,
    degradationRatePercent: 1.1,
    transientVulnerability: 'STABLE',
    recommendation: 'Routine quarterly cathodic protection voltage check. Maintain current operational threshold.',
    primaryStressFactor: 'Normal operational hydraulic wear.',
    lastSimulatedHammerBar: 4.8
  },
  {
    id: 'pred-04',
    segmentId: 'SEG-WRG-034',
    segmentName: 'West Residential Feeder Loop',
    zoneName: 'West Residential Grid',
    burstRiskScore: 16,
    riskLevel: 'LOW',
    remainingUsefulLifeMonths: 140,
    degradationRatePercent: 0.8,
    transientVulnerability: 'STABLE',
    recommendation: 'System operating at optimal design parameters. No intervention needed.',
    primaryStressFactor: 'Minimal hydraulic resistance.',
    lastSimulatedHammerBar: 3.6
  }
];

export const INITIAL_AUDIT_STATS: WaterAuditStats = {
  totalSuppliedM3: 4280500,
  totalBilledM3: 3972304,
  nonRevenueWaterM3: 308196,
  nrwPercentage: 7.2, // low compared to industry average of 25-40%
  acousticLeaksFound: 84,
  physicalLossSavedM3: 142680,
  costSavedInr: 28536000 // ₹2.85 Crore saved
};

export const INITIAL_AGENT_LOGS: AgentLog[] = [
  {
    id: 'log-01',
    timestamp: '14:12:04',
    step: 'ACT',
    targetNodeOrValve: 'PRV-09 (South)',
    description: 'Auto-throttled Pressure Reducing Valve by 18% to damp upstream surge and isolate segment SEG-SIS-410.',
    confidence: 97.2,
    automatedActionApplied: true
  },
  {
    id: 'log-02',
    timestamp: '14:11:58',
    step: 'DECIDE',
    targetNodeOrValve: 'Zone SIS-02 Subgrid',
    description: 'Selected Valve Damping Strategy #4B: Mitigates downstream water hammer without starving critical industrial consumers.',
    confidence: 94.8,
    automatedActionApplied: true
  },
  {
    id: 'log-03',
    timestamp: '14:11:32',
    step: 'ORIENT',
    targetNodeOrValve: 'Node S-02 & S-01',
    description: 'Correlated 78.4 dB hydrophone vibration spike with sudden -1.2 Bar pressure gradient. Probability of active rupture: 96.4%.',
    confidence: 96.4,
    automatedActionApplied: false
  },
  {
    id: 'log-04',
    timestamp: '14:11:15',
    step: 'OBSERVE',
    targetNodeOrValve: 'SCADA Telemetry Mesh',
    description: 'Detected anomalous telemetry packet rate from Node S-02: delta pressure exceeds threshold of 0.4 Bar/sec.',
    confidence: 99.1,
    automatedActionApplied: false
  },
  {
    id: 'log-05',
    timestamp: '13:45:20',
    step: 'ACT',
    targetNodeOrValve: 'Pump Station #2',
    description: 'Gradual soft-ramp execution applied to Variable Frequency Drive #3 to prevent transient hydraulic wave.',
    confidence: 98.0,
    automatedActionApplied: true
  }
];
