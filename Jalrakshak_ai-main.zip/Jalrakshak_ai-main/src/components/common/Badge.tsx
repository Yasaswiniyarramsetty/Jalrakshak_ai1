import React from 'react';
import clsx from 'clsx';
import { Severity, NodeStatus } from '../../types/pipeline';

interface SeverityBadgeProps {
  severity: Severity;
  className?: string;
}

export const SeverityBadge: React.FC<SeverityBadgeProps> = ({ severity, className }) => {
  const configs = {
    P1_CRITICAL: {
      label: 'P1 CRITICAL',
      bg: 'bg-rose-500/15 text-rose-300 border-rose-500/40',
      dot: 'bg-rose-500 animate-ping',
    },
    P2_HIGH: {
      label: 'P2 HIGH',
      bg: 'bg-amber-500/15 text-amber-300 border-amber-500/40',
      dot: 'bg-amber-400',
    },
    P3_MODERATE: {
      label: 'P3 MODERATE',
      bg: 'bg-sky-500/15 text-sky-300 border-sky-500/40',
      dot: 'bg-sky-400',
    },
    P4_LOW: {
      label: 'P4 ADVISORY',
      bg: 'bg-slate-500/15 text-slate-300 border-slate-500/40',
      dot: 'bg-slate-400',
    },
  }[severity];

  return (
    <span
      className={clsx(
        'inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-mono font-medium border uppercase tracking-wider',
        configs.bg,
        className
      )}
    >
      <span className={clsx('w-1.5 h-1.5 rounded-full inline-block', configs.dot)} />
      {configs.label}
    </span>
  );
};

interface StatusBadgeProps {
  status: NodeStatus;
  className?: string;
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status, className }) => {
  const configs = {
    ONLINE: {
      label: 'ONLINE',
      bg: 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30',
      dot: 'bg-emerald-400',
    },
    DEGRADED: {
      label: 'DEGRADED',
      bg: 'bg-amber-500/10 text-amber-300 border-amber-500/30',
      dot: 'bg-amber-400 animate-pulse',
    },
    OFFLINE: {
      label: 'OFFLINE',
      bg: 'bg-rose-500/10 text-rose-300 border-rose-500/30',
      dot: 'bg-rose-400',
    },
  }[status];

  return (
    <span
      className={clsx(
        'inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[11px] font-mono font-semibold border uppercase tracking-wider',
        configs.bg,
        className
      )}
    >
      <span className={clsx('w-1.5 h-1.5 rounded-full', configs.dot)} />
      {configs.label}
    </span>
  );
};

export const LiveIndicator: React.FC<{ label?: string; className?: string }> = ({
  label = 'LIVE SCADA',
  className,
}) => (
  <span
    className={clsx(
      'inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-cyan-500/10 border border-cyan-400/30 text-cyan-300 text-xs font-mono font-semibold tracking-wider uppercase',
      className
    )}
  >
    <span className="relative flex h-2 w-2">
      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
      <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-500"></span>
    </span>
    {label}
  </span>
);
