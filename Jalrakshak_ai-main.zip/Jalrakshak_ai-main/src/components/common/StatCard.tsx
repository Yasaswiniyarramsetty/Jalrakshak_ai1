import React from 'react';
import clsx from 'clsx';
import { ArrowUpRight, ArrowDownRight, Minus } from 'lucide-react';

interface StatCardProps {
  title: string;
  value: string | number;
  unit?: string;
  change?: number;
  changeLabel?: string;
  icon: React.ReactNode;
  accent?: 'cyan' | 'blue' | 'emerald' | 'amber' | 'rose';
  subtitle?: string;
}

export const StatCard: React.FC<StatCardProps> = ({
  title,
  value,
  unit,
  change,
  changeLabel = 'vs normal baseline',
  icon,
  accent = 'cyan',
  subtitle,
}) => {
  const accentStyles = {
    cyan: {
      border: 'border-cyan-500/20 hover:border-cyan-400/50',
      iconBg: 'bg-cyan-500/10 text-cyan-400 border-cyan-400/30',
      glow: 'hover:shadow-[0_0_20px_rgba(6,182,212,0.2)]',
    },
    blue: {
      border: 'border-sky-500/20 hover:border-sky-400/50',
      iconBg: 'bg-sky-500/10 text-sky-400 border-sky-400/30',
      glow: 'hover:shadow-[0_0_20px_rgba(14,165,233,0.2)]',
    },
    emerald: {
      border: 'border-emerald-500/20 hover:border-emerald-400/50',
      iconBg: 'bg-emerald-500/10 text-emerald-400 border-emerald-400/30',
      glow: 'hover:shadow-[0_0_20px_rgba(16,185,129,0.2)]',
    },
    amber: {
      border: 'border-amber-500/20 hover:border-amber-400/50',
      iconBg: 'bg-amber-500/10 text-amber-400 border-amber-400/30',
      glow: 'hover:shadow-[0_0_20px_rgba(245,158,11,0.2)]',
    },
    rose: {
      border: 'border-rose-500/20 hover:border-rose-400/50',
      iconBg: 'bg-rose-500/10 text-rose-400 border-rose-400/30',
      glow: 'hover:shadow-[0_0_20px_rgba(244,63,94,0.2)]',
    },
  }[accent];

  const renderTrend = () => {
    if (change === undefined) return null;
    const isPositive = change > 0;
    const isNeutral = change === 0;

    return (
      <div className="flex items-center gap-1 mt-2 text-xs font-mono">
        <span
          className={clsx(
            'inline-flex items-center font-medium px-1.5 py-0.5 rounded',
            isNeutral && 'text-slate-400 bg-slate-800/50',
            isPositive && 'text-emerald-400 bg-emerald-500/10',
            !isPositive && !isNeutral && 'text-rose-400 bg-rose-500/10'
          )}
        >
          {isPositive ? <ArrowUpRight className="w-3 h-3 mr-0.5" /> : null}
          {!isPositive && !isNeutral ? <ArrowDownRight className="w-3 h-3 mr-0.5" /> : null}
          {isNeutral ? <Minus className="w-3 h-3 mr-0.5" /> : null}
          {change > 0 ? `+${change}%` : `${change}%`}
        </span>
        <span className="text-slate-400 text-[11px] truncate">{changeLabel}</span>
      </div>
    );
  };

  return (
    <div
      className={clsx(
        'relative rounded-xl bg-navy-900/75 backdrop-blur-xl border p-5 transition-all duration-300',
        accentStyles.border,
        accentStyles.glow
      )}
    >
      {/* Corner styling */}
      <div className="absolute top-0 left-0 w-2 h-2 border-t-2 border-l-2 border-cyan-400/40 rounded-tl" />

      <div className="flex items-start justify-between">
        <div className="flex-1">
          <p className="text-xs font-medium uppercase tracking-wider text-slate-400 font-display">
            {title}
          </p>
          <div className="flex items-baseline gap-2 mt-2">
            <span className="text-2xl lg:text-3xl font-bold font-mono tracking-tight text-white drop-shadow-sm">
              {value}
            </span>
            {unit && (
              <span className="text-xs font-mono text-cyan-300 font-medium">
                {unit}
              </span>
            )}
          </div>
          {renderTrend()}
          {subtitle && (
            <p className="text-[11px] text-slate-400 mt-2 font-sans truncate">{subtitle}</p>
          )}
        </div>

        <div
          className={clsx(
            'p-3 rounded-lg border flex items-center justify-center shrink-0 shadow-inner',
            accentStyles.iconBg
          )}
        >
          {icon}
        </div>
      </div>
    </div>
  );
};
