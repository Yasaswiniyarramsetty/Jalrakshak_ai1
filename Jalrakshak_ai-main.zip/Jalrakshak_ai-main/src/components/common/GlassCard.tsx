import React from 'react';
import clsx from 'clsx';

interface GlassCardProps extends Omit<React.HTMLAttributes<HTMLDivElement>, 'title'> {
  children: React.ReactNode;
  className?: string;
  glow?: 'none' | 'cyan' | 'blue' | 'red' | 'amber' | 'emerald';
  title?: React.ReactNode;
  subtitle?: React.ReactNode;
  headerAction?: React.ReactNode;
  badge?: React.ReactNode;
}

export const GlassCard: React.FC<GlassCardProps> = ({
  children,
  className,
  glow = 'none',
  title,
  subtitle,
  headerAction,
  badge,
  ...props
}) => {
  const glowClasses = {
    none: 'border-cyan-500/15 shadow-glass-card',
    cyan: 'border-cyan-400/35 shadow-glow-cyan',
    blue: 'border-sky-400/35 shadow-glow-blue',
    red: 'border-rose-500/40 shadow-glow-red',
    amber: 'border-amber-500/35 shadow-[0_0_20px_rgba(245,158,11,0.2)]',
    emerald: 'border-emerald-500/35 shadow-[0_0_20px_rgba(16,185,129,0.2)]',
  }[glow];

  return (
    <div
      className={clsx(
        'relative rounded-xl bg-navy-900/70 backdrop-blur-xl border transition-all duration-300 overflow-hidden',
        glowClasses,
        className
      )}
      {...props}
    >
      {/* Corner cyber accent lines */}
      <div className="absolute top-0 left-0 w-3 h-[2px] bg-cyan-400/60" />
      <div className="absolute top-0 left-0 w-[2px] h-3 bg-cyan-400/60" />
      <div className="absolute top-0 right-0 w-3 h-[2px] bg-cyan-400/60" />
      <div className="absolute top-0 right-0 w-[2px] h-3 bg-cyan-400/60" />

      {/* Header bar if title is provided */}
      {(title || headerAction || badge) && (
        <div className="flex items-center justify-between px-5 py-4 border-b border-cyan-500/10 bg-navy-850/40">
          <div className="flex items-center gap-3">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-display font-semibold text-slate-100 text-sm tracking-wider uppercase">
                  {title}
                </h3>
                {badge}
              </div>
              {subtitle && (
                <p className="text-xs text-slate-400 mt-0.5 font-sans">
                  {subtitle}
                </p>
              )}
            </div>
          </div>
          {headerAction && (
            <div className="flex items-center gap-2">{headerAction}</div>
          )}
        </div>
      )}

      {/* Card Body */}
      <div className="p-5">{children}</div>
    </div>
  );
};
