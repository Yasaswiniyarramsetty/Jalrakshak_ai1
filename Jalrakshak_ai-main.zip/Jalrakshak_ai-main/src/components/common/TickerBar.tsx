import React from 'react';
import { Activity, ShieldAlert, Wifi, Cpu } from 'lucide-react';
import { LiveIndicator } from './Badge';

interface TickerBarProps {
  lastPacketTime?: string;
  activeSensorsCount: number;
  totalSensorsCount: number;
  criticalAlertsCount: number;
  avgPressure: number;
  currentLossRateLpm: number;
}

export const TickerBar: React.FC<TickerBarProps> = ({
  lastPacketTime = '0.4s ago',
  activeSensorsCount,
  totalSensorsCount,
  criticalAlertsCount,
  avgPressure,
  currentLossRateLpm,
}) => {
  return (
    <div className="w-full bg-navy-950/90 border-y border-cyan-500/20 px-4 py-2 flex flex-wrap items-center justify-between text-xs font-mono text-slate-300 gap-3">
      <div className="flex items-center gap-4 flex-wrap">
        <LiveIndicator label="SCADA MESH" />

        <div className="flex items-center gap-1.5 text-slate-300">
          <Wifi className="w-3.5 h-3.5 text-cyan-400" />
          <span>NODES ONLINE:</span>
          <span className="text-cyan-300 font-bold">
            {activeSensorsCount}/{totalSensorsCount} (96.8%)
          </span>
        </div>

        <div className="h-3 w-[1px] bg-slate-700 hidden sm:block" />

        <div className="flex items-center gap-1.5 text-slate-300">
          <Activity className="w-3.5 h-3.5 text-sky-400" />
          <span>SYSTEM HYDRAULIC MEAN:</span>
          <span className="text-white font-bold">{avgPressure.toFixed(2)} Bar</span>
        </div>

        <div className="h-3 w-[1px] bg-slate-700 hidden md:block" />

        <div className="flex items-center gap-1.5 text-slate-300">
          <Cpu className="w-3.5 h-3.5 text-emerald-400" />
          <span>VARUNA AI INFERENCE LATENCY:</span>
          <span className="text-emerald-300 font-semibold">142ms</span>
        </div>
      </div>

      <div className="flex items-center gap-4">
        {criticalAlertsCount > 0 ? (
          <div className="flex items-center gap-1.5 text-rose-400 animate-pulse bg-rose-500/10 px-2.5 py-0.5 rounded border border-rose-500/30">
            <ShieldAlert className="w-3.5 h-3.5" />
            <span className="font-bold">{criticalAlertsCount} ACTIVE P1 HAZARD</span>
            <span className="text-[10px] text-rose-300">({currentLossRateLpm} L/min)</span>
          </div>
        ) : (
          <div className="flex items-center gap-1.5 text-emerald-400">
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span>GRID EQUILIBRIUM NOMINAL</span>
          </div>
        )}

        <div className="text-[11px] text-slate-500">
          PACKET: <span className="text-slate-400">{lastPacketTime}</span>
        </div>
      </div>
    </div>
  );
};
