import React from 'react';
import { 
  LayoutDashboard, 
  Network, 
  Activity, 
  BrainCircuit, 
  Boxes, 
  Droplets, 
  AlertTriangle, 
  Bot, 
  FileText, 
  Settings,
  ChevronLeft,
  ChevronRight,
  Shield,
  Radio
} from 'lucide-react';
import { PageId } from '../../types/pipeline';
import clsx from 'clsx';

interface SidebarProps {
  currentPage: PageId;
  onPageChange: (page: PageId) => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
  activeAlertsCount: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentPage,
  onPageChange,
  isCollapsed,
  onToggleCollapse,
  activeAlertsCount,
}) => {
  const navItems: { id: PageId; label: string; icon: React.ComponentType<{ className?: string }>; badge?: number }[] = [
    { id: 'command-center', label: 'Command Center', icon: LayoutDashboard },
    { id: 'pipeline-network', label: 'Pipeline Network', icon: Network },
    { id: 'live-monitoring', label: 'Live Monitoring', icon: Activity },
    { id: 'ai-predictions', label: 'AI Predictions', icon: BrainCircuit },
    { id: 'digital-twin', label: 'Digital Twin', icon: Boxes },
    { id: 'water-loss', label: 'Water Loss Analysis', icon: Droplets },
    { id: 'alerts-incidents', label: 'Alerts & Incidents', icon: AlertTriangle, badge: activeAlertsCount },
    { id: 'ai-agent', label: 'AI Agent (Varuna)', icon: Bot },
    { id: 'reports', label: 'Reports & Audits', icon: FileText },
    { id: 'settings', label: 'System Settings', icon: Settings },
  ];

  return (
    <aside
      className={clsx(
        'relative flex flex-col bg-navy-950/95 border-r border-cyan-500/15 backdrop-blur-2xl transition-all duration-300 z-30 select-none h-screen shrink-0',
        isCollapsed ? 'w-20' : 'w-72'
      )}
    >
      {/* Brand Header */}
      <div className="p-4 border-b border-cyan-500/15 flex items-center justify-between">
        <div className="flex items-center gap-3 overflow-hidden">
          <div className="relative w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-400 to-sky-600 flex items-center justify-center shrink-0 shadow-lg shadow-cyan-500/25">
            <Shield className="w-6 h-6 text-navy-950 stroke-[2.5]" />
            <div className="absolute -top-1 -right-1 w-3 h-3 bg-emerald-400 rounded-full border-2 border-navy-950 animate-pulse" />
          </div>

          {!isCollapsed && (
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5">
                <span className="font-display font-extrabold tracking-wider text-base text-white">
                  JALRAKSHAK
                </span>
                <span className="px-1.5 py-0.5 rounded bg-cyan-500/20 text-cyan-300 text-[10px] font-mono font-bold border border-cyan-400/30">
                  AI
                </span>
              </div>
              <p className="text-[10px] text-slate-400 tracking-tight line-clamp-1 leading-tight mt-0.5">
                Underground Pipeline Command
              </p>
            </div>
          )}
        </div>

        {/* Collapse Button */}
        <button
          onClick={onToggleCollapse}
          className="hidden md:flex p-1.5 rounded-lg text-slate-400 hover:text-cyan-300 hover:bg-slate-800/60 transition-colors"
          title={isCollapsed ? 'Expand Sidebar' : 'Collapse Sidebar'}
          aria-label={isCollapsed ? 'Expand Sidebar' : 'Collapse Sidebar'}
        >
          {isCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
        </button>
      </div>

      {/* Navigation List */}
      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1.5">
        <div className={clsx('px-3 mb-2 text-[10px] font-mono uppercase tracking-wider text-slate-500', isCollapsed && 'sr-only')}>
          Operations Grid
        </div>

        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentPage === item.id;

          return (
            <button
              key={item.id}
              onClick={() => onPageChange(item.id)}
              className={clsx(
                'w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 group relative',
                isActive
                  ? 'bg-gradient-to-r from-cyan-500/20 to-sky-500/10 text-cyan-300 border border-cyan-400/30 shadow-[0_0_15px_rgba(6,182,212,0.15)]'
                  : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800/40 border border-transparent'
              )}
              title={isCollapsed ? item.label : undefined}
            >
              {/* Active neon strip */}
              {isActive && (
                <div className="absolute left-0 top-2 bottom-2 w-1 rounded-r bg-cyan-400 shadow-[0_0_8px_#00f2fe]" />
              )}

              <Icon
                className={clsx(
                  'w-5 h-5 shrink-0 transition-transform duration-200 group-hover:scale-110',
                  isActive ? 'text-cyan-400' : 'text-slate-400 group-hover:text-cyan-300'
                )}
              />

              {!isCollapsed && (
                <span className="flex-1 text-left truncate font-sans">{item.label}</span>
              )}

              {/* Alerts or badge */}
              {item.badge !== undefined && item.badge > 0 && (
                <span
                  className={clsx(
                    'px-2 py-0.5 rounded-full text-[11px] font-mono font-bold shrink-0',
                    item.id === 'alerts-incidents'
                      ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30 animate-pulse'
                      : 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                  )}
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Footer System Status Widget */}
      {!isCollapsed ? (
        <div className="p-3 mx-3 mb-4 rounded-xl bg-navy-900/80 border border-cyan-500/15 text-xs">
          <div className="flex items-center justify-between text-slate-400 mb-1.5">
            <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400">Core Telemetry</span>
            <span className="flex items-center gap-1 text-[10px] font-mono text-emerald-400">
              <Radio className="w-3 h-3 animate-pulse" /> SCADA 100%
            </span>
          </div>
          <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden mb-2">
            <div className="bg-gradient-to-r from-cyan-400 to-sky-500 h-full w-[96%]" />
          </div>
          <div className="text-[10px] text-slate-400 font-mono flex justify-between">
            <span>Ping: 18ms</span>
            <span>Uptime: 99.98%</span>
          </div>
        </div>
      ) : (
        <div className="p-3 flex justify-center border-t border-cyan-500/15">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" title="SCADA Online" />
        </div>
      )}
    </aside>
  );
};
