import React, { useState, useEffect } from 'react';
import { 
  Clock, 
  ShieldAlert, 
  Layers, 
  Bell, 
  UserCheck, 
  Volume2, 
  VolumeX,
  Sparkles
} from 'lucide-react';
import { PageId, Zone } from '../../types/pipeline';
import clsx from 'clsx';

interface HeaderProps {
  currentPage: PageId;
  zones: Zone[];
  selectedZone: string;
  onZoneSelect: (zoneId: string) => void;
  emergencyMode: boolean;
  onToggleEmergency: () => void;
  criticalIncidentsCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  currentPage,
  zones,
  selectedZone,
  onZoneSelect,
  emergencyMode,
  onToggleEmergency,
  criticalIncidentsCount,
}) => {
  const [timeStr, setTimeStr] = useState<string>('');
  const [dateStr, setDateStr] = useState<string>('');
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(now.toLocaleTimeString('en-IN', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' }));
      setDateStr(now.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }));
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const pageTitles: Record<PageId, { title: string; subtitle: string }> = {
    'command-center': {
      title: 'Command Center Overview',
      subtitle: 'Real-time grid integrity, hydraulic balance & emergency dispatch matrix',
    },
    'pipeline-network': {
      title: 'Pipeline Network GIS',
      subtitle: 'Subterranean distribution schematic, trunk lines, nodes & PRVs',
    },
    'live-monitoring': {
      title: 'Live Telemetry Stream',
      subtitle: 'Multi-parameter sensor mesh: Pressure, Acoustic, Flow & Water Quality',
    },
    'ai-predictions': {
      title: 'Predictive Intelligence',
      subtitle: 'Burst risk probability, Remaining Useful Life (RUL) & water hammer transients',
    },
    'digital-twin': {
      title: 'Digital Twin Simulation',
      subtitle: 'Interactive hydraulic cross-section model & simulated stress injection',
    },
    'water-loss': {
      title: 'Water Loss & NRW Analytics',
      subtitle: 'Acoustic leak correlation, non-revenue water audit & conservation yield',
    },
    'alerts-incidents': {
      title: 'Alerts & Incident Dispatch',
      subtitle: 'Automated triage, rapid crew routing & valve isolation protocol',
    },
    'ai-agent': {
      title: 'Varuna AI Operations Agent',
      subtitle: 'Autonomous OODA loop reasoning, predictive throttling & command terminal',
    },
    'reports': {
      title: 'Audits & Regulatory Reports',
      subtitle: 'Central Water Commission (CWC) compliance, telemetry exports & audit logs',
    },
    'settings': {
      title: 'System & SCADA Settings',
      subtitle: 'IoT gateway brokers, threshold limits, LoRaWAN polling & security credentials',
    },
  };

  const currentInfo = pageTitles[currentPage];

  return (
    <header
      className={clsx(
        'relative bg-navy-950/85 backdrop-blur-xl border-b px-6 py-3.5 flex flex-wrap items-center justify-between gap-4 transition-colors duration-300 z-20',
        emergencyMode ? 'border-rose-500/50 bg-rose-950/20' : 'border-cyan-500/15'
      )}
    >
      {/* Title & Tagline Breadcrumb */}
      <div>
        <div className="flex items-center gap-3">
          <h1 className="text-xl font-bold font-display tracking-tight text-white flex items-center gap-2">
            {currentInfo.title}
          </h1>
          {emergencyMode && (
            <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-bold bg-rose-500/20 text-rose-400 border border-rose-500/40 animate-pulse">
              EMERGENCY PROTOCOL ACTIVE
            </span>
          )}
        </div>
        <p className="text-xs text-slate-400 mt-0.5">
          {currentInfo.subtitle}
        </p>
      </div>

      {/* Control Bar: Sector Selector, Emergency Toggle, Clock, User */}
      <div className="flex items-center gap-3 flex-wrap">
        {/* Sector Filter Dropdown */}
        <div className="flex items-center gap-2 bg-navy-900/80 border border-cyan-500/20 rounded-xl px-3 py-1.5 text-xs">
          <Layers className="w-3.5 h-3.5 text-cyan-400" />
          <span className="text-slate-400 font-mono hidden sm:inline">SECTOR:</span>
          <select
            value={selectedZone}
            onChange={(e) => onZoneSelect(e.target.value)}
            className="bg-transparent text-cyan-300 font-mono font-medium focus:outline-none cursor-pointer pr-2"
          >
            <option value="all" className="bg-navy-900 text-slate-100">All Sectors (Master Grid)</option>
            {zones.map((z) => (
              <option key={z.id} value={z.id} className="bg-navy-900 text-slate-100">
                {z.name} ({z.code})
              </option>
            ))}
          </select>
        </div>

        {/* Emergency Mode Button */}
        <button
          onClick={onToggleEmergency}
          className={clsx(
            'flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-mono font-bold tracking-wider transition-all duration-200 border',
            emergencyMode
              ? 'bg-rose-500 text-white border-rose-400 shadow-glow-red animate-pulse'
              : 'bg-navy-900/80 hover:bg-rose-500/20 text-rose-300 border-rose-500/30'
          )}
          title="Toggle High Alert Emergency Protocol"
        >
          <ShieldAlert className="w-4 h-4" />
          <span className="hidden sm:inline">
            {emergencyMode ? 'STAND DOWN' : 'EMERGENCY SCRAM'}
          </span>
        </button>

        {/* Sound toggle */}
        <button
          onClick={() => setSoundEnabled(!soundEnabled)}
          className="p-2 rounded-xl bg-navy-900/80 border border-cyan-500/20 text-slate-400 hover:text-cyan-300 transition-colors"
          title={soundEnabled ? 'Mute Telemetry Audio' : 'Unmute Telemetry Audio'}
          aria-label={soundEnabled ? 'Mute Telemetry Audio' : 'Unmute Telemetry Audio'}
        >
          {soundEnabled ? <Volume2 className="w-4 h-4 text-cyan-400" /> : <VolumeX className="w-4 h-4" />}
        </button>

        {/* Digital Clock Widget */}
        <div className="hidden lg:flex items-center gap-2 bg-navy-900/80 border border-cyan-500/20 rounded-xl px-3 py-1.5 text-xs font-mono">
          <Clock className="w-3.5 h-3.5 text-cyan-400" />
          <span className="text-white font-semibold">{timeStr}</span>
          <span className="text-slate-500">|</span>
          <span className="text-slate-400">{dateStr} IST</span>
        </div>

        {/* Operator Badge */}
        <div className="flex items-center gap-2.5 pl-2 border-l border-cyan-500/20">
          <div className="w-8 h-8 rounded-lg bg-cyan-500/10 border border-cyan-400/30 flex items-center justify-center text-cyan-300">
            <UserCheck className="w-4 h-4" />
          </div>
          <div className="hidden xl:block text-left">
            <div className="text-xs font-semibold text-white leading-tight">Chief Controller</div>
            <div className="text-[10px] text-cyan-400 font-mono">SCADA LEVEL 4</div>
          </div>
        </div>
      </div>
    </header>
  );
};
