import React, { useState } from 'react';
import { Sidebar } from './Sidebar';
import { Header } from './Header';
import { TickerBar } from '../common/TickerBar';
import { PageId, Zone } from '../../types/pipeline';

interface DashboardLayoutProps {
  currentPage: PageId;
  onPageChange: (page: PageId) => void;
  zones: Zone[];
  selectedZone: string;
  onZoneSelect: (zoneId: string) => void;
  emergencyMode: boolean;
  onToggleEmergency: () => void;
  activeSensorsCount: number;
  totalSensorsCount: number;
  criticalAlertsCount: number;
  avgPressure: number;
  currentLossRateLpm: number;
  children: React.ReactNode;
}

export const DashboardLayout: React.FC<DashboardLayoutProps> = ({
  currentPage,
  onPageChange,
  zones,
  selectedZone,
  onZoneSelect,
  emergencyMode,
  onToggleEmergency,
  activeSensorsCount,
  totalSensorsCount,
  criticalAlertsCount,
  avgPressure,
  currentLossRateLpm,
  children,
}) => {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState<boolean>(false);

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-navy-950 text-slate-100 bg-grid-cyber bg-radial-vignette relative">
      {/* Background cyber ambient glow spots */}
      <div className="absolute top-0 left-1/4 w-[600px] h-[600px] bg-cyan-600/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-1/4 w-[500px] h-[500px] bg-sky-600/5 rounded-full blur-3xl pointer-events-none" />

      {/* Sidebar Navigation */}
      <Sidebar
        currentPage={currentPage}
        onPageChange={onPageChange}
        isCollapsed={isSidebarCollapsed}
        onToggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
        activeAlertsCount={criticalAlertsCount}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 h-screen overflow-hidden">
        {/* Header Bar */}
        <Header
          currentPage={currentPage}
          zones={zones}
          selectedZone={selectedZone}
          onZoneSelect={onZoneSelect}
          emergencyMode={emergencyMode}
          onToggleEmergency={onToggleEmergency}
          criticalIncidentsCount={criticalAlertsCount}
        />

        {/* Live Telemetry Ticker */}
        <TickerBar
          activeSensorsCount={activeSensorsCount}
          totalSensorsCount={totalSensorsCount}
          criticalAlertsCount={criticalAlertsCount}
          avgPressure={avgPressure}
          currentLossRateLpm={currentLossRateLpm}
        />

        {/* Page View Container */}
        <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
          {children}
        </main>
      </div>
    </div>
  );
};
