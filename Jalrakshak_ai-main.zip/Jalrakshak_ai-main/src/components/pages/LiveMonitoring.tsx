import React, { useState } from 'react';
import { 
  Activity, 
  Wifi, 
  Battery, 
  Radio, 
  Cpu, 
  Play, 
  Pause, 
  Sliders, 
  Droplet, 
  Thermometer, 
  CheckCircle2, 
  AlertOctagon,
  RefreshCw
} from 'lucide-react';
import { GlassCard } from '../common/GlassCard';
import { StatusBadge, LiveIndicator } from '../common/Badge';
import { SensorNode, TelemetryPoint } from '../../types/pipeline';

interface LiveMonitoringProps {
  nodes: SensorNode[];
  telemetryHistory: TelemetryPoint[];
  isSimulating: boolean;
  onToggleSimulating: () => void;
}

export const LiveMonitoring: React.FC<LiveMonitoringProps> = ({
  nodes,
  telemetryHistory,
  isSimulating,
  onToggleSimulating,
}) => {
  const [activeTab, setActiveTab] = useState<'pressure' | 'flow' | 'acoustic' | 'quality'>('pressure');
  const [selectedNodeId, setSelectedNodeId] = useState<string>(nodes[0]?.id || 'node-n01');

  const selectedNode = nodes.find((n) => n.id === selectedNodeId) || nodes[0];

  // Helper to render responsive SVG polyline charts for telemetry
  const renderChart = () => {
    const height = 180;
    const width = 800;
    const points = telemetryHistory;

    let values: number[] = [];
    let unit = '';
    let strokeColor = '#00f2fe';
    let gradientId = 'grad-cyan';

    if (activeTab === 'pressure') {
      values = points.map((p) => p.pressure);
      unit = 'Bar';
      strokeColor = '#00f2fe';
      gradientId = 'grad-cyan';
    } else if (activeTab === 'flow') {
      values = points.map((p) => p.flow);
      unit = 'L/s';
      strokeColor = '#38bdf8';
      gradientId = 'grad-blue';
    } else if (activeTab === 'acoustic') {
      values = points.map((p) => p.acoustic);
      unit = 'dB';
      strokeColor = '#f43f5e';
      gradientId = 'grad-red';
    } else {
      values = points.map((p) => p.ph);
      unit = 'pH';
      strokeColor = '#10b981';
      gradientId = 'grad-emerald';
    }

    const minVal = Math.min(...values) * 0.9;
    const maxVal = Math.max(...values) * 1.1 || 1;
    const range = maxVal - minVal || 1;

    const svgPoints = values.map((val, idx) => {
      const x = (idx / (values.length - 1)) * width;
      const y = height - ((val - minVal) / range) * (height - 20) - 10;
      return `${x},${y}`;
    }).join(' ');

    const lastVal = values[values.length - 1];

    return (
      <div className="relative w-full">
        {/* Header Indicator */}
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono text-slate-400">CURRENT TELEMETRY READING:</span>
            <span className="text-xl font-bold font-mono text-white">
              {lastVal} {unit}
            </span>
          </div>
          <div className="text-xs font-mono text-slate-400">
            Min: <strong className="text-slate-200">{Math.min(...values).toFixed(2)}</strong> | Max: <strong className="text-slate-200">{Math.max(...values).toFixed(2)}</strong> {unit}
          </div>
        </div>

        {/* SVG Spark Area Chart */}
        <div className="relative h-48 w-full bg-navy-950/80 rounded-xl border border-cyan-500/20 p-2 overflow-hidden">
          {/* Horizontal Reference Grid Lines */}
          <div className="absolute inset-0 flex flex-col justify-between p-4 pointer-events-none opacity-20">
            <div className="border-b border-cyan-500/40 w-full" />
            <div className="border-b border-cyan-500/40 w-full" />
            <div className="border-b border-cyan-500/40 w-full" />
          </div>

          <svg className="w-full h-full" viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none">
            <defs>
              <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={strokeColor} stopOpacity="0.35" />
                <stop offset="100%" stopColor={strokeColor} stopOpacity="0.0" />
              </linearGradient>
            </defs>

            {/* Filled Area */}
            <polygon
              points={`0,${height} ${svgPoints} ${width},${height}`}
              fill={`url(#${gradientId})`}
            />

            {/* Stroke Polyline */}
            <polyline
              fill="none"
              stroke={strokeColor}
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
              points={svgPoints}
            />

            {/* Live blinking tip at latest point */}
            {values.length > 0 && (
              <circle
                cx={width}
                cy={height - ((lastVal - minVal) / range) * (height - 20) - 10}
                r="4"
                fill="#ffffff"
                stroke={strokeColor}
                strokeWidth="2"
              >
                <animate attributeName="r" values="3;6;3" dur="1.5s" repeatCount="indefinite" />
              </circle>
            )}
          </svg>
        </div>

        {/* Time Labels */}
        <div className="flex justify-between text-[10px] font-mono text-slate-500 mt-1.5">
          <span>{points[0]?.time || 'T - 60s'}</span>
          <span>{points[Math.floor(points.length / 2)]?.time || 'T - 30s'}</span>
          <span className="text-cyan-400 font-bold">{points[points.length - 1]?.time || 'NOW'}</span>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Control Strip */}
      <div className="p-4 rounded-xl bg-navy-900/80 border border-cyan-500/20 backdrop-blur-md flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-4 flex-wrap">
          <LiveIndicator label="SCADA SENSOR STREAM" />

          {/* Target Node Selector */}
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono text-slate-400">MONITORED NODE:</span>
            <select
              value={selectedNodeId}
              onChange={(e) => setSelectedNodeId(e.target.value)}
              className="bg-navy-950 border border-cyan-500/30 rounded-lg px-3 py-1.5 text-xs font-mono text-cyan-300 font-semibold focus:outline-none focus:border-cyan-400"
            >
              {nodes.map((n) => (
                <option key={n.id} value={n.id}>
                  {n.name} ({n.id.toUpperCase()}) — {n.zoneName}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onToggleSimulating}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono font-medium border transition-colors ${
              isSimulating
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/30 hover:bg-amber-500/30'
                : 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30 hover:bg-cyan-500/30'
            }`}
          >
            {isSimulating ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            <span>{isSimulating ? 'Pause Stream' : 'Resume Stream'}</span>
          </button>

          <span className="text-xs font-mono text-slate-400 flex items-center gap-1">
            <RefreshCw className={`w-3.5 h-3.5 text-cyan-400 ${isSimulating ? 'animate-spin' : ''}`} style={{ animationDuration: '3s' }} />
            2.5s Polling
          </span>
        </div>
      </div>

      {/* Main Chart Card */}
      <GlassCard
        title={`Continuous Telemetry Waveform: ${selectedNode.name}`}
        subtitle={`Sensor #${selectedNode.id.toUpperCase()} • Sector: ${selectedNode.zoneName}`}
        glow="cyan"
        headerAction={
          <div className="flex items-center gap-1 bg-navy-950 p-1 rounded-lg border border-cyan-500/20">
            <button
              onClick={() => setActiveTab('pressure')}
              className={`px-3 py-1 rounded text-xs font-mono transition-colors ${
                activeTab === 'pressure' ? 'bg-cyan-500 text-navy-950 font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              Pressure
            </button>
            <button
              onClick={() => setActiveTab('flow')}
              className={`px-3 py-1 rounded text-xs font-mono transition-colors ${
                activeTab === 'flow' ? 'bg-cyan-500 text-navy-950 font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              Flow Rate
            </button>
            <button
              onClick={() => setActiveTab('acoustic')}
              className={`px-3 py-1 rounded text-xs font-mono transition-colors ${
                activeTab === 'acoustic' ? 'bg-cyan-500 text-navy-950 font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              Acoustics
            </button>
            <button
              onClick={() => setActiveTab('quality')}
              className={`px-3 py-1 rounded text-xs font-mono transition-colors ${
                activeTab === 'quality' ? 'bg-cyan-500 text-navy-950 font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              Water Quality
            </button>
          </div>
        }
      >
        {renderChart()}
      </GlassCard>

      {/* Secondary Row: Live Sensor Telemetry Parameters & Sensor Node Hardware Health */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Real-time Readings Grid for Monitored Node */}
        <GlassCard
          title="Multi-Parameter Sensor Array"
          subtitle="Instantaneous hydraulic & physicochemical values"
        >
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            <div className="p-3 rounded-xl bg-navy-950/70 border border-cyan-500/20">
              <span className="text-[10px] font-mono text-slate-400 uppercase">Pressure</span>
              <div className="text-xl font-bold font-mono text-cyan-300 mt-1">
                {selectedNode.readings.pressureBar} <span className="text-xs">Bar</span>
              </div>
              <span className="text-[10px] text-slate-500">Piezoresistive Transducer</span>
            </div>

            <div className="p-3 rounded-xl bg-navy-950/70 border border-cyan-500/20">
              <span className="text-[10px] font-mono text-slate-400 uppercase">Flow Rate</span>
              <div className="text-xl font-bold font-mono text-sky-300 mt-1">
                {selectedNode.readings.flowLps} <span className="text-xs">L/s</span>
              </div>
              <span className="text-[10px] text-slate-500">Electromagnetic Flowmeter</span>
            </div>

            <div className="p-3 rounded-xl bg-navy-950/70 border border-cyan-500/20">
              <span className="text-[10px] font-mono text-slate-400 uppercase">Acoustic Signal</span>
              <div className={`text-xl font-bold font-mono mt-1 ${selectedNode.readings.acousticDb > 50 ? 'text-rose-400' : 'text-emerald-400'}`}>
                {selectedNode.readings.acousticDb} <span className="text-xs">dB</span>
              </div>
              <span className="text-[10px] text-slate-500">Sub-surface Hydrophone</span>
            </div>

            <div className="p-3 rounded-xl bg-navy-950/70 border border-cyan-500/20">
              <span className="text-[10px] font-mono text-slate-400 uppercase">Acidity (pH)</span>
              <div className="text-xl font-bold font-mono text-emerald-300 mt-1">
                {selectedNode.readings.ph}
              </div>
              <span className="text-[10px] text-slate-500">ISFET Glass Electrode</span>
            </div>

            <div className="p-3 rounded-xl bg-navy-950/70 border border-cyan-500/20">
              <span className="text-[10px] font-mono text-slate-400 uppercase">Turbidity</span>
              <div className="text-xl font-bold font-mono text-amber-300 mt-1">
                {selectedNode.readings.turbidityNtu} <span className="text-xs">NTU</span>
              </div>
              <span className="text-[10px] text-slate-500">Nephelometric Optical</span>
            </div>

            <div className="p-3 rounded-xl bg-navy-950/70 border border-cyan-500/20">
              <span className="text-[10px] font-mono text-slate-400 uppercase">Residual Cl</span>
              <div className="text-xl font-bold font-mono text-cyan-300 mt-1">
                {selectedNode.readings.chlorineMgL} <span className="text-xs">mg/L</span>
              </div>
              <span className="text-[10px] text-slate-500">Potentiometric Sensor</span>
            </div>
          </div>
        </GlassCard>

        {/* Hardware & Mesh Health Matrix */}
        <GlassCard
          title="IoT Node Telemetry Diagnostics"
          subtitle="Subterranean transmitter battery, RSSI & calibration"
        >
          <div className="space-y-3 font-mono text-xs">
            <div className="p-3 rounded-xl bg-navy-950/70 border border-cyan-500/15 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Battery className="w-4 h-4 text-emerald-400" />
                <span>Internal Lithium Battery:</span>
              </div>
              <span className="text-emerald-400 font-bold">{selectedNode.batteryLevel}% (Estimated 4.2 yrs life)</span>
            </div>

            <div className="p-3 rounded-xl bg-navy-950/70 border border-cyan-500/15 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Wifi className="w-4 h-4 text-cyan-400" />
                <span>LoRaWAN Gateway Link:</span>
              </div>
              <span className="text-cyan-300 font-bold">{selectedNode.rssi} dBm (Signal: Strong)</span>
            </div>

            <div className="p-3 rounded-xl bg-navy-950/70 border border-cyan-500/15 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Cpu className="w-4 h-4 text-sky-400" />
                <span>Microcontroller Temperature:</span>
              </div>
              <span className="text-slate-200">{selectedNode.readings.tempC} °C</span>
            </div>

            <div className="p-3 rounded-xl bg-navy-950/70 border border-cyan-500/15 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Zero-Point Drift Calibration:</span>
              </div>
              <span className="text-emerald-400">PASSED (Calibrated 18d ago)</span>
            </div>
          </div>
        </GlassCard>
      </div>
    </div>
  );
};
