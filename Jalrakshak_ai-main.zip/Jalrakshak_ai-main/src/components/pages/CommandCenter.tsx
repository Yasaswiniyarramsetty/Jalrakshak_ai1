import React from 'react';
import { 
  Activity, 
  Droplets, 
  ShieldCheck, 
  AlertTriangle, 
  Gauge, 
  ArrowRight,
  Radio,
  Zap,
  Bot,
  MapPin,
  TrendingDown
} from 'lucide-react';
import { GlassCard } from '../common/GlassCard';
import { StatCard } from '../common/StatCard';
import { SeverityBadge, StatusBadge } from '../common/Badge';
import { Zone, SensorNode, Incident, AiPrediction, PageId } from '../../types/pipeline';

interface CommandCenterProps {
  zones: Zone[];
  nodes: SensorNode[];
  incidents: Incident[];
  predictions: AiPrediction[];
  onNavigate: (page: PageId) => void;
  onSelectNode: (node: SensorNode) => void;
  onAcknowledgeIncident: (id: string) => void;
}

export const CommandCenter: React.FC<CommandCenterProps> = ({
  zones,
  nodes,
  incidents,
  predictions,
  onNavigate,
  onSelectNode,
  onAcknowledgeIncident,
}) => {
  const activeIncidents = incidents.filter((i) => i.status !== 'RESOLVED');
  const criticalIncidents = incidents.filter((i) => i.severity === 'P1_CRITICAL' && i.status !== 'RESOLVED');
  const avgPressure = nodes.reduce((acc, n) => acc + n.readings.pressureBar, 0) / (nodes.length || 1);

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Top Banner: Brand Tagline & Smart City Status */}
      <div className="relative rounded-2xl p-6 bg-gradient-to-r from-navy-900/90 via-navy-850/90 to-cyan-950/40 border border-cyan-500/20 backdrop-blur-xl overflow-hidden shadow-2xl">
        <div className="absolute -right-12 -top-12 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2 py-0.5 rounded text-[11px] font-mono font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-400/30">
                SCADA AI COMMAND MESH
              </span>
              <span className="text-xs font-mono text-slate-400 flex items-center gap-1">
                <Radio className="w-3 h-3 text-emerald-400 animate-pulse" /> 24x7 REAL-TIME OVERSIGHT
              </span>
            </div>
            <h2 className="text-2xl lg:text-3xl font-bold font-display tracking-tight text-white">
              JalRakshak AI City Water Operations
            </h2>
            <p className="text-sm text-slate-300 mt-1 max-w-2xl">
              Intelligent Underground Water Pipeline Monitoring & Predictive Maintenance System. Continuous subterranean acoustics, hydraulic transients & autonomous pressure regulation.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => onNavigate('digital-twin')}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-navy-950 font-semibold text-sm transition-all shadow-glow-cyan"
            >
              <Zap className="w-4 h-4" />
              <span>Launch 3D Digital Twin</span>
            </button>
            <button
              onClick={() => onNavigate('ai-agent')}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-navy-800 hover:bg-navy-700 text-cyan-300 border border-cyan-500/30 font-medium text-sm transition-all"
            >
              <Bot className="w-4 h-4" />
              <span>Consult Varuna AI</span>
            </button>
          </div>
        </div>
      </div>

      {/* Primary KPI Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Grid Hydraulic Mean"
          value={avgPressure.toFixed(2)}
          unit="Bar"
          change={-1.8}
          changeLabel="Target: 4.2 Bar"
          icon={<Gauge className="w-5 h-5" />}
          accent="cyan"
          subtitle="4 Sectors, 842.5 km total trunk lines"
        />
        <StatCard
          title="Grid Integrity Index"
          value="98.4"
          unit="%"
          change={0.6}
          changeLabel="Nominal safety envelope"
          icon={<ShieldCheck className="w-5 h-5" />}
          accent="emerald"
          subtitle="Cathodic protection & vibration baseline"
        />
        <StatCard
          title="Non-Revenue Water (NRW)"
          value="7.2"
          unit="%"
          change={-2.4}
          changeLabel="Industry standard: 25-40%"
          icon={<Droplets className="w-5 h-5" />}
          accent="blue"
          subtitle="₹2.85 Cr subterranean loss prevented"
        />
        <StatCard
          title="Active Alert Triage"
          value={activeIncidents.length}
          unit="Incidents"
          change={criticalIncidents.length > 0 ? 1 : 0}
          changeLabel={criticalIncidents.length > 0 ? 'P1 Critical active' : 'All stabilized'}
          icon={<AlertTriangle className="w-5 h-5" />}
          accent={criticalIncidents.length > 0 ? 'rose' : 'emerald'}
          subtitle={`${criticalIncidents.length} Critical, ${activeIncidents.length - criticalIncidents.length} Advisory`}
        />
      </div>

      {/* Main Command Split: Interactive Grid Map & Sector Telemetry */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Smart City Pipeline GIS Overview */}
        <div className="lg:col-span-2">
          <GlassCard
            title="Metropolitan Pipeline Schematic (GIS)"
            subtitle="Underground telemetry nodes, hydraulic gradients and acoustic alert locations"
            glow="cyan"
            headerAction={
              <button
                onClick={() => onNavigate('pipeline-network')}
                className="text-xs font-mono text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
              >
                <span>Full GIS Network</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            }
          >
            {/* Interactive SVG City Schematic */}
            <div className="relative w-full h-80 sm:h-96 rounded-xl bg-navy-950/80 border border-cyan-500/20 overflow-hidden flex items-center justify-center p-2">
              {/* Grid Background */}
              <div className="absolute inset-0 bg-grid-cyber opacity-40" />

              <svg className="w-full h-full" viewBox="0 0 1000 600">
                {/* City Sector Area Zones */}
                <rect x="50" y="40" width="420" height="240" rx="16" fill="rgba(6, 182, 212, 0.04)" stroke="rgba(6, 182, 212, 0.2)" strokeDasharray="4 4" />
                <text x="70" y="70" fill="#22d3ee" fontSize="14" fontFamily="Outfit" fontWeight="bold">NORTH TRANSMISSION (NTC-01)</text>

                <rect x="530" y="40" width="420" height="240" rx="16" fill="rgba(14, 165, 233, 0.04)" stroke="rgba(14, 165, 233, 0.2)" strokeDasharray="4 4" />
                <text x="550" y="70" fill="#38bdf8" fontSize="14" fontFamily="Outfit" fontWeight="bold">EAST COMMERCIAL (ECW-03)</text>

                <rect x="50" y="320" width="420" height="240" rx="16" fill="rgba(16, 185, 129, 0.04)" stroke="rgba(16, 185, 129, 0.2)" strokeDasharray="4 4" />
                <text x="70" y="350" fill="#34d399" fontSize="14" fontFamily="Outfit" fontWeight="bold">WEST RESIDENTIAL (WRG-04)</text>

                <rect x="530" y="320" width="420" height="240" rx="16" fill="rgba(244, 63, 94, 0.06)" stroke="rgba(244, 63, 94, 0.3)" strokeDasharray="4 4" />
                <text x="550" y="350" fill="#fb7185" fontSize="14" fontFamily="Outfit" fontWeight="bold">SOUTH INDUSTRIAL (SIS-02) — HAZARD</text>

                {/* Subterranean Trunk Pipelines */}
                {/* Main Arterial Flow */}
                <path d="M 220 160 L 380 180 L 720 190 L 820 220" fill="none" stroke="#00f2fe" strokeWidth="5" strokeLinecap="round" opacity="0.8" />
                <path d="M 380 180 L 280 440 L 180 480" fill="none" stroke="#38bdf8" strokeWidth="4" strokeLinecap="round" opacity="0.8" />
                <path d="M 380 180 L 550 420 L 680 470" fill="none" stroke="#f43f5e" strokeWidth="5" strokeLinecap="round" strokeDasharray="8 4" opacity="0.9" />

                {/* Animated Flow Pulse Effect */}
                <circle cx="300" cy="170" r="3" fill="#ffffff">
                  <animate attributeName="opacity" values="0.2;1;0.2" dur="2s" repeatCount="indefinite" />
                </circle>

                {/* Hazard Burst Ring Animation at Node S-02 */}
                <circle cx="680" cy="470" r="28" fill="none" stroke="#f43f5e" strokeWidth="2">
                  <animate attributeName="r" values="12;35" dur="1.8s" repeatCount="indefinite" />
                  <animate attributeName="opacity" values="0.8;0" dur="1.8s" repeatCount="indefinite" />
                </circle>

                {/* Sensor Nodes */}
                {nodes.map((node) => {
                  const cx = (node.x / 100) * 1000;
                  const cy = (node.y / 100) * 600;
                  const isCritical = node.status === 'DEGRADED';

                  return (
                    <g
                      key={node.id}
                      onClick={() => onSelectNode(node)}
                      className="cursor-pointer group"
                    >
                      {/* Node Outer Glow */}
                      <circle
                        cx={cx}
                        cy={cy}
                        r={isCritical ? 14 : 10}
                        fill={isCritical ? 'rgba(244, 63, 94, 0.3)' : 'rgba(6, 182, 212, 0.25)'}
                        className="group-hover:scale-125 transition-transform"
                      />
                      {/* Node Core */}
                      <circle
                        cx={cx}
                        cy={cy}
                        r={isCritical ? 8 : 6}
                        fill={isCritical ? '#ff3366' : '#00f2fe'}
                        stroke="#030712"
                        strokeWidth="2"
                      />
                      {/* Label */}
                      <text
                        x={cx + 12}
                        y={cy + 4}
                        fill="#f1f5f9"
                        fontSize="11"
                        fontFamily="JetBrains Mono"
                        fontWeight="600"
                        className="pointer-events-none drop-shadow"
                      >
                        {node.id.toUpperCase()} ({node.readings.pressureBar}b)
                      </text>
                    </g>
                  );
                })}
              </svg>

              {/* Map Legend Overlay */}
              <div className="absolute bottom-3 left-3 bg-navy-900/90 border border-cyan-500/20 rounded-lg p-2.5 text-[11px] font-mono flex items-center gap-4">
                <div className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-cyan-400" />
                  <span>Trunk Main (Normal)</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse" />
                  <span>Pressure Drop / Burst</span>
                </div>
                <div className="flex items-center gap-1.5 text-slate-400">
                  <MapPin className="w-3 h-3 text-cyan-400" />
                  <span>Click node to inspect</span>
                </div>
              </div>
            </div>
          </GlassCard>
        </div>

        {/* Right 1 Col: Sector Health Breakdown */}
        <div className="space-y-4">
          <GlassCard
            title="Sector Hydraulic Balance"
            subtitle="Real-time pressure & loss index per district"
          >
            <div className="space-y-3">
              {zones.map((zone) => {
                const isCritical = zone.status === 'CRITICAL';
                const isAdvisory = zone.status === 'ADVISORY';

                return (
                  <div
                    key={zone.id}
                    className="p-3 rounded-xl bg-navy-850/60 border border-cyan-500/10 hover:border-cyan-500/30 transition-colors"
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="font-display font-semibold text-xs text-white">
                        {zone.name}
                      </span>
                      <span
                        className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded uppercase ${
                          isCritical
                            ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                            : isAdvisory
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                            : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                        }`}
                      >
                        {zone.status}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-xs font-mono text-slate-400 mb-2">
                      <span>Pressure: <strong className="text-white">{zone.avgPressure} Bar</strong></span>
                      <span>Loss: <strong className={zone.lossRatePercent > 10 ? 'text-rose-400' : 'text-cyan-400'}>{zone.lossRatePercent}%</strong></span>
                    </div>

                    <div className="w-full bg-navy-950 h-1.5 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full ${
                          isCritical
                            ? 'bg-rose-500 w-[88%]'
                            : isAdvisory
                            ? 'bg-amber-500 w-[65%]'
                            : 'bg-gradient-to-r from-cyan-400 to-emerald-400 w-[94%]'
                        }`}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </GlassCard>

          {/* Varuna AI Live Autonomous Advisory */}
          <GlassCard
            title="Varuna AI Autonomous Loop"
            subtitle="Autonomous pressure damper & valve orchestrator"
            glow="blue"
            headerAction={
              <button
                onClick={() => onNavigate('ai-agent')}
                className="text-xs font-mono text-cyan-300 hover:underline"
              >
                Inspect Logs
              </button>
            }
          >
            <div className="p-3 rounded-lg bg-navy-950/70 border border-cyan-500/20 text-xs">
              <div className="flex items-center gap-2 text-cyan-400 font-mono text-[11px] mb-1">
                <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
                <span>ACTIVE MITIGATION: PRV-09 THROTTLED</span>
              </div>
              <p className="text-slate-300 leading-relaxed">
                Varuna AI preemptively throttled Upstream PRV-09 by 18% following an acoustic spike (78.4 dB) at Node S-02. Hydraulic wave dampening prevented secondary burst at Node S-01.
              </p>
            </div>
          </GlassCard>
        </div>
      </div>

      {/* Bottom Row: Active Incidents Triage & Predictions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Incident Triage List */}
        <GlassCard
          title="Active Incident Triage"
          subtitle="Real-time acoustic & pressure rupture alerts"
          headerAction={
            <button
              onClick={() => onNavigate('alerts-incidents')}
              className="text-xs font-mono text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
            >
              <span>View All ({incidents.length})</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          }
        >
          <div className="space-y-3">
            {activeIncidents.slice(0, 3).map((incident) => (
              <div
                key={incident.id}
                className="p-3.5 rounded-xl bg-navy-850/60 border border-cyan-500/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <SeverityBadge severity={incident.severity} />
                    <span className="text-xs font-mono text-slate-400">{incident.code}</span>
                    <span className="text-xs text-slate-400">• {incident.timestamp}</span>
                  </div>
                  <h4 className="font-semibold text-sm text-slate-100 mt-1">
                    {incident.title}
                  </h4>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Zone: <span className="text-cyan-300">{incident.zoneName}</span> | Loss Rate: <span className="text-rose-400 font-mono">{incident.estimatedLossRateLpm} L/min</span>
                  </p>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                  {incident.status === 'ACTIVE' && (
                    <button
                      onClick={() => onAcknowledgeIncident(incident.id)}
                      className="px-3 py-1.5 rounded-lg text-xs font-mono font-medium bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-400/30 transition-colors"
                    >
                      Acknowledge
                    </button>
                  )}
                  <button
                    onClick={() => onNavigate('alerts-incidents')}
                    className="px-3 py-1.5 rounded-lg text-xs font-mono font-medium bg-navy-800 hover:bg-navy-700 text-slate-300 border border-slate-700 transition-colors"
                  >
                    Action
                  </button>
                </div>
              </div>
            ))}
          </div>
        </GlassCard>

        {/* AI Predictive Risk Spotlight */}
        <GlassCard
          title="Predictive Pipe Degradation"
          subtitle="Top underground segments vulnerable to transient failure"
          headerAction={
            <button
              onClick={() => onNavigate('ai-predictions')}
              className="text-xs font-mono text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
            >
              <span>AI Predictions</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          }
        >
          <div className="space-y-3">
            {predictions.slice(0, 3).map((pred) => (
              <div
                key={pred.id}
                className="p-3 rounded-xl bg-navy-850/60 border border-cyan-500/10 space-y-2"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <span className="font-display font-semibold text-xs text-slate-100">
                      {pred.segmentName}
                    </span>
                    <p className="text-[11px] text-slate-400 font-sans">
                      Primary Stress: {pred.primaryStressFactor}
                    </p>
                  </div>
                  <div className="text-right">
                    <span
                      className={`text-xs font-mono font-bold px-2 py-0.5 rounded ${
                        pred.riskLevel === 'EXTREME'
                          ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                          : pred.riskLevel === 'HIGH'
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                          : 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                      }`}
                    >
                      Risk: {pred.burstRiskScore}%
                    </span>
                    <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                      RUL: {pred.remainingUsefulLifeMonths} mos
                    </div>
                  </div>
                </div>

                <div className="w-full bg-navy-950 h-1.5 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full ${
                      pred.burstRiskScore > 75
                        ? 'bg-rose-500'
                        : pred.burstRiskScore > 50
                        ? 'bg-amber-400'
                        : 'bg-cyan-400'
                    }`}
                    style={{ width: `${pred.burstRiskScore}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </GlassCard>
      </div>
    </div>
  );
};
