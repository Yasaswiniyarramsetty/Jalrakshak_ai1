import React, { useState } from 'react';
import { 
  Bot, 
  Send, 
  Sparkles, 
  Cpu, 
  CheckCircle2, 
  Terminal, 
  ShieldAlert, 
  Sliders, 
  Zap, 
  Activity,
  CornerDownLeft,
  RotateCcw
} from 'lucide-react';
import { GlassCard } from '../common/GlassCard';
import { AgentLog } from '../../types/pipeline';

interface AiAgentProps {
  agentLogs: AgentLog[];
  onSendCommand: (prompt: string) => string;
}

export const AiAgent: React.FC<AiAgentProps> = ({ agentLogs, onSendCommand }) => {
  const [operatorPrompt, setOperatorPrompt] = useState<string>('');
  const [messages, setMessages] = useState<Array<{ sender: 'user' | 'agent'; text: string; time: string }>>([
    {
      sender: 'agent',
      text: 'VARUNA AI ONLINE: Autonomous Subterranean Water Operations Agent active. Monitoring 842.5 km of pipelines with continuous OODA loop reasoning. How can I assist with grid equilibrium or incident containment?',
      time: '14:10:00',
    },
    {
      sender: 'agent',
      text: 'AUTONOMOUS ADVISORY: Hydrophone telemetry at Node S-02 exceeded 78.4 dB. I have autonomously throttled upstream PRV-09 to 38% capacity to prevent catastrophic water hammer rupture in South Industrial Sector.',
      time: '14:12:04',
    }
  ]);
  const [autonomyMode, setAutonomyMode] = useState<'FULL_AUTONOMOUS' | 'SUPERVISED' | 'ADVISORY'>('FULL_AUTONOMOUS');

  const handleSend = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!operatorPrompt.trim()) return;

    const userText = operatorPrompt;
    const nowTime = new Date().toLocaleTimeString('en-IN', { hour12: false });

    // Append user message
    const newMessages = [...messages, { sender: 'user' as const, text: userText, time: nowTime }];
    setMessages(newMessages);
    setOperatorPrompt('');

    // Synthesize response
    setTimeout(() => {
      const response = onSendCommand(userText);
      setMessages((prev) => [
        ...prev,
        {
          sender: 'agent' as const,
          text: response,
          time: new Date().toLocaleTimeString('en-IN', { hour12: false }),
        }
      ]);
    }, 400);
  };

  const presetQueries = [
    'Analyze pressure anomalies in South Industrial Sector',
    'What is our total Non-Revenue Water (NRW) savings today?',
    'Evaluate water hammer transient risk across transmission lines',
    'Recommend automated valve schedule for night-time low demand'
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header Banner */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-navy-900/90 via-navy-850/90 to-cyan-950/40 border border-cyan-500/20 backdrop-blur-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2 py-0.5 rounded text-[11px] font-mono font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-400/30">
              AGENTIC CO-PILOT: VARUNA AI
            </span>
            <span className="text-xs font-mono text-emerald-400 flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" /> AUTONOMOUS REASONING LOOP ACTIVE
            </span>
          </div>
          <h2 className="text-2xl font-bold font-display text-white">
            Autonomous Pipeline Operations & Valve Orchestration
          </h2>
          <p className="text-xs text-slate-300 mt-1 max-w-2xl">
            Performs Observe-Orient-Decide-Act (OODA) loops at sub-second latency, commanding motorized SCADA valves to quench water hammer shocks before human operators could intervene.
          </p>
        </div>

        {/* Autonomy Mode Selector */}
        <div className="p-3 rounded-xl bg-navy-950/80 border border-cyan-500/20 text-xs font-mono">
          <span className="text-slate-400 block text-[10px] mb-1">AGENT AUTONOMY LEVEL</span>
          <div className="flex items-center gap-1">
            <button
              onClick={() => setAutonomyMode('FULL_AUTONOMOUS')}
              className={`px-2.5 py-1 rounded text-xs transition-colors ${
                autonomyMode === 'FULL_AUTONOMOUS'
                  ? 'bg-cyan-500 text-navy-950 font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Full Autonomous (&lt;200ms)
            </button>
            <button
              onClick={() => setAutonomyMode('SUPERVISED')}
              className={`px-2.5 py-1 rounded text-xs transition-colors ${
                autonomyMode === 'SUPERVISED'
                  ? 'bg-cyan-500 text-navy-950 font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Supervised
            </button>
            <button
              onClick={() => setAutonomyMode('ADVISORY')}
              className={`px-2.5 py-1 rounded text-xs transition-colors ${
                autonomyMode === 'ADVISORY'
                  ? 'bg-cyan-500 text-navy-950 font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Advisory
            </button>
          </div>
        </div>
      </div>

      {/* Main Grid: Interactive Chat Console & Live OODA Loop Action Stream */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left Col: Interactive Operator Prompt Terminal */}
        <GlassCard
          title="Varuna AI Command Terminal"
          subtitle="Query hydraulic models, simulate mitigation, or command autonomous agents"
          glow="cyan"
        >
          <div className="flex flex-col h-[520px]">
            {/* Message Feed */}
            <div className="flex-1 overflow-y-auto space-y-3 p-2 pr-3">
              {messages.map((m, idx) => (
                <div
                  key={idx}
                  className={`flex flex-col ${
                    m.sender === 'user' ? 'items-end' : 'items-start'
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1 text-[10px] font-mono text-slate-400">
                    <span>{m.sender === 'user' ? 'CHIEF CONTROLLER' : 'VARUNA AGENT CORE'}</span>
                    <span>• {m.time}</span>
                  </div>
                  <div
                    className={`p-3.5 rounded-2xl max-w-[85%] text-xs leading-relaxed font-sans ${
                      m.sender === 'user'
                        ? 'bg-cyan-500 text-navy-950 font-medium rounded-tr-none'
                        : 'bg-navy-950/90 text-slate-100 border border-cyan-500/20 rounded-tl-none font-mono'
                    }`}
                  >
                    {m.text}
                  </div>
                </div>
              ))}
            </div>

            {/* Quick Prompt Chips */}
            <div className="py-2 border-t border-cyan-500/10 flex flex-wrap gap-1.5">
              {presetQueries.map((chip, i) => (
                <button
                  key={i}
                  onClick={() => setOperatorPrompt(chip)}
                  className="px-2.5 py-1 rounded-lg bg-navy-950 border border-cyan-500/20 hover:border-cyan-400/40 text-slate-300 hover:text-cyan-300 text-[11px] font-mono transition-colors truncate max-w-full"
                >
                  {chip}
                </button>
              ))}
            </div>

            {/* Input Box */}
            <form onSubmit={handleSend} className="pt-2 flex items-center gap-2">
              <div className="relative flex-1">
                <input
                  type="text"
                  value={operatorPrompt}
                  onChange={(e) => setOperatorPrompt(e.target.value)}
                  placeholder="Ask Varuna AI: analyze, isolate or simulate..."
                  className="w-full bg-navy-950 border border-cyan-500/30 rounded-xl px-4 py-2.5 text-xs font-mono text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                />
              </div>
              <button
                type="submit"
                className="p-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-navy-950 font-bold transition-all shadow-glow-cyan"
                title="Send Command"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </GlassCard>

        {/* Right Col: Autonomous OODA Reasoning Audit Stream */}
        <GlassCard
          title="Autonomous OODA Reasoning Logs"
          subtitle="Real-time audit log of agent observation, orientation, decision & actuation"
          glow="blue"
        >
          <div className="space-y-3 max-h-[520px] overflow-y-auto pr-2">
            {agentLogs.map((log) => {
              const stepStyles = {
                OBSERVE: { label: 'OBSERVE', color: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40' },
                ORIENT: { label: 'ORIENT', color: 'bg-sky-500/20 text-sky-300 border-sky-500/40' },
                DECIDE: { label: 'DECIDE', color: 'bg-amber-500/20 text-amber-300 border-amber-500/40' },
                ACT: { label: 'ACT', color: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' },
              }[log.step];

              return (
                <div
                  key={log.id}
                  className="p-3.5 rounded-xl bg-navy-950/70 border border-cyan-500/15 space-y-2 text-xs font-mono"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${stepStyles.color}`}>
                        {stepStyles.label}
                      </span>
                      <span className="text-slate-400 text-[11px]">{log.timestamp}</span>
                    </div>

                    <div className="flex items-center gap-2 text-[11px]">
                      <span className="text-slate-400">Target:</span>
                      <strong className="text-white">{log.targetNodeOrValve}</strong>
                    </div>
                  </div>

                  <p className="text-slate-200 font-sans leading-relaxed text-xs">
                    {log.description}
                  </p>

                  <div className="flex items-center justify-between pt-1 border-t border-cyan-500/10 text-[11px] text-slate-400">
                    <span>AI Confidence: <strong className="text-cyan-300">{log.confidence}%</strong></span>
                    {log.automatedActionApplied && (
                      <span className="text-emerald-400 font-bold flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> AUTONOMOUS ACTUATION EXECUTED
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </GlassCard>
      </div>
    </div>
  );
};
