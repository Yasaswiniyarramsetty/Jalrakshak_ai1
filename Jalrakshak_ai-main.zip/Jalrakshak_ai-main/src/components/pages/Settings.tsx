import React, { useState } from 'react';
import { 
  Settings as SettingsIcon, 
  Wifi, 
  ShieldAlert, 
  Sliders, 
  Save, 
  RefreshCw, 
  Key, 
  Bell, 
  Server, 
  Database,
  Cpu,
  CheckCircle2
} from 'lucide-react';
import { GlassCard } from '../common/GlassCard';

export const Settings: React.FC = () => {
  const [mqttBroker, setMqttBroker] = useState<string>('mqtts://scada-mesh.jalrakshak.gov.in:8883');
  const [loraPort, setLoraPort] = useState<string>('868.1 MHz (EU868/IN865)');
  const [pollingRate, setPollingRate] = useState<number>(2.5);
  const [maxPressure, setMaxPressure] = useState<number>(6.5);
  const [minPressure, setMinPressure] = useState<number>(2.0);
  const [acousticLimit, setAcousticLimit] = useState<number>(45);
  const [autoThrottling, setAutoThrottling] = useState<boolean>(true);
  const [isSaved, setIsSaved] = useState<boolean>(false);

  const handleSave = () => {
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2500);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Top Header */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-navy-900/90 via-navy-850/90 to-cyan-950/40 border border-cyan-500/20 backdrop-blur-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2 py-0.5 rounded text-[11px] font-mono font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-400/30">
              SYSTEM CONFIGURATION MATRIX
            </span>
            <span className="text-xs font-mono text-cyan-400">
              SCADA LEVEL 4 ROOT ACCESS
            </span>
          </div>
          <h2 className="text-2xl font-bold font-display text-white">
            SCADA Gateway, Sensor Mesh & Alarm Thresholds
          </h2>
          <p className="text-xs text-slate-300 mt-1 max-w-2xl">
            Configure telemetry transport protocols, LoRaWAN gateways, automated valve actuation parameters, and hydraulic alarm thresholds.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleSave}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-navy-950 font-semibold text-xs font-mono uppercase tracking-wider transition-all shadow-glow-cyan"
          >
            <Save className="w-4 h-4" />
            <span>{isSaved ? 'Parameters Saved!' : 'Save System Config'}</span>
          </button>
        </div>
      </div>

      {isSaved && (
        <div className="p-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-mono flex items-center gap-2 animate-fade-in">
          <CheckCircle2 className="w-4 h-4" />
          <span>SCADA Gateway parameters synchronized with all remote RTUs and Varuna AI orchestrator.</span>
        </div>
      )}

      {/* Main Settings Sections */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* IoT Gateway & Protocol Transport */}
        <GlassCard
          title="IoT Gateway & SCADA Connectivity"
          subtitle="MQTT, Modbus TCP & LoRaWAN Gateway parameters"
          glow="cyan"
        >
          <div className="space-y-4 text-xs font-mono">
            <div className="space-y-1.5">
              <label className="text-slate-300 block">MQTT BROKER SECURE ENDPOINT:</label>
              <input
                type="text"
                value={mqttBroker}
                onChange={(e) => setMqttBroker(e.target.value)}
                className="w-full bg-navy-950 border border-cyan-500/20 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-cyan-400 font-mono"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-slate-300 block">LoRaWAN FREQUENCY & BAND:</label>
              <input
                type="text"
                value={loraPort}
                onChange={(e) => setLoraPort(e.target.value)}
                className="w-full bg-navy-950 border border-cyan-500/20 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-cyan-400 font-mono"
              />
            </div>

            <div className="space-y-2 pt-2">
              <div className="flex justify-between text-slate-300">
                <span>Telemetry Polling Frequency:</span>
                <strong className="text-cyan-300">{pollingRate} Seconds</strong>
              </div>
              <input
                type="range"
                min="0.5"
                max="10.0"
                step="0.5"
                value={pollingRate}
                onChange={(e) => setPollingRate(parseFloat(e.target.value))}
                className="w-full accent-cyan-400 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-500">
                <span>0.5s (High Precision)</span>
                <span>5.0s (Standard)</span>
                <span>10.0s (Eco Mesh)</span>
              </div>
            </div>

            <div className="p-3 rounded-lg bg-navy-950/80 border border-cyan-500/10 space-y-1 text-[11px] text-slate-400">
              <div className="flex justify-between">
                <span>Gateway Status:</span>
                <strong className="text-emerald-400">CONNECTED (TLS 1.3 AES-256)</strong>
              </div>
              <div className="flex justify-between">
                <span>Modbus Slave ID:</span>
                <strong className="text-slate-200">0x04 (Master PLC Ring)</strong>
              </div>
            </div>
          </div>
        </GlassCard>

        {/* Hydraulic Alarm Thresholds */}
        <GlassCard
          title="Hydraulic Alarm Thresholds"
          subtitle="Trigger parameters for P1 to P4 automated alerts"
          glow="amber"
        >
          <div className="space-y-4 text-xs font-mono">
            <div className="space-y-2">
              <div className="flex justify-between text-slate-300">
                <span>Maximum Surge Pressure (Water Hammer Trip):</span>
                <strong className="text-rose-400">{maxPressure} Bar</strong>
              </div>
              <input
                type="range"
                min="4.0"
                max="10.0"
                step="0.2"
                value={maxPressure}
                onChange={(e) => setMaxPressure(parseFloat(e.target.value))}
                className="w-full accent-rose-400 cursor-pointer"
              />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-slate-300">
                <span>Minimum Delivery Pressure Threshold:</span>
                <strong className="text-amber-300">{minPressure} Bar</strong>
              </div>
              <input
                type="range"
                min="1.0"
                max="3.5"
                step="0.1"
                value={minPressure}
                onChange={(e) => setMinPressure(parseFloat(e.target.value))}
                className="w-full accent-amber-400 cursor-pointer"
              />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-slate-300">
                <span>Hydrophone Acoustic Leak Trip:</span>
                <strong className="text-cyan-300">{acousticLimit} dB</strong>
              </div>
              <input
                type="range"
                min="20"
                max="70"
                step="1"
                value={acousticLimit}
                onChange={(e) => setAcousticLimit(parseInt(e.target.value))}
                className="w-full accent-cyan-400 cursor-pointer"
              />
            </div>

            <div className="p-3 rounded-lg bg-navy-950/80 border border-cyan-500/10 flex items-center justify-between">
              <div>
                <span className="text-slate-200 font-semibold block">Varuna AI Automated Actuation</span>
                <span className="text-[10px] text-slate-400">Allow autonomous PRV throttling without manual operator confirmation</span>
              </div>
              <button
                onClick={() => setAutoThrottling(!autoThrottling)}
                className={`w-12 h-6 rounded-full transition-colors relative ${
                  autoThrottling ? 'bg-cyan-500' : 'bg-slate-700'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white transition-transform ${
                    autoThrottling ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>
          </div>
        </GlassCard>
      </div>
    </div>
  );
};
