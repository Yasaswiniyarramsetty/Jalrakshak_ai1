import React, { useState } from 'react';
import { 
  Network, 
  Layers, 
  MapPin, 
  Filter, 
  Gauge, 
  Droplets, 
  Sliders, 
  Activity, 
  ShieldCheck, 
  Wrench,
  X
} from 'lucide-react';
import { GlassCard } from '../common/GlassCard';
import { StatusBadge } from '../common/Badge';
import { Zone, SensorNode } from '../../types/pipeline';

interface PipelineNetworkProps {
  zones: Zone[];
  nodes: SensorNode[];
  selectedNode: SensorNode | null;
  onSelectNode: (node: SensorNode | null) => void;
}

export const PipelineNetwork: React.FC<PipelineNetworkProps> = ({
  zones,
  nodes,
  selectedNode,
  onSelectNode,
}) => {
  const [filterZone, setFilterZone] = useState<string>('all');
  const [filterMaterial, setFilterMaterial] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const filteredNodes = nodes.filter((node) => {
    if (filterZone !== 'all' && node.zoneId !== filterZone) return false;
    if (filterMaterial !== 'all' && node.pipeMaterial !== filterMaterial) return false;
    if (searchQuery && !node.name.toLowerCase().includes(searchQuery.toLowerCase()) && !node.id.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }
    return true;
  });

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Top Filter and Search Bar */}
      <div className="p-4 rounded-xl bg-navy-900/80 border border-cyan-500/20 backdrop-blur-md flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-2 text-xs font-mono text-cyan-300">
            <Filter className="w-4 h-4 text-cyan-400" />
            <span>GRID FILTERS:</span>
          </div>

          {/* Zone filter */}
          <select
            value={filterZone}
            onChange={(e) => setFilterZone(e.target.value)}
            className="bg-navy-950 border border-cyan-500/20 rounded-lg px-3 py-1.5 text-xs font-mono text-slate-200 focus:outline-none focus:border-cyan-400"
          >
            <option value="all">All Sectors ({nodes.length} Nodes)</option>
            {zones.map((z) => (
              <option key={z.id} value={z.id}>{z.name}</option>
            ))}
          </select>

          {/* Pipe Material filter */}
          <select
            value={filterMaterial}
            onChange={(e) => setFilterMaterial(e.target.value)}
            className="bg-navy-950 border border-cyan-500/20 rounded-lg px-3 py-1.5 text-xs font-mono text-slate-200 focus:outline-none focus:border-cyan-400"
          >
            <option value="all">All Materials</option>
            <option value="Ductile Iron">Ductile Iron (DI)</option>
            <option value="HDPE">High Density Polyethylene (HDPE)</option>
            <option value="Pre-stressed Concrete">Pre-stressed Concrete (PSC)</option>
            <option value="Cast Iron">Cast Iron (CI)</option>
            <option value="Mild Steel">Mild Steel (MS)</option>
          </select>

          {/* Text search */}
          <input
            type="text"
            placeholder="Search node or ID..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="bg-navy-950 border border-cyan-500/20 rounded-lg px-3 py-1.5 text-xs font-mono text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-400 w-48"
          />
        </div>

        <div className="flex items-center gap-4 text-xs font-mono text-slate-400">
          <span>Active Nodes Visible: <strong className="text-cyan-300">{filteredNodes.length}</strong></span>
          <span>Mesh Density: <strong className="text-white">1.1 sensors/km</strong></span>
        </div>
      </div>

      {/* Main Grid: Interactive GIS Map & Selected Node Telemetry Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Network Visualizer */}
        <div className="lg:col-span-2">
          <GlassCard
            title="Subterranean Water Grid Topology"
            subtitle="Click any sensor node or PRV valve to inspect underground hydraulic parameters"
            glow="cyan"
          >
            <div className="relative w-full h-[450px] rounded-xl bg-navy-950 border border-cyan-500/20 overflow-hidden flex items-center justify-center">
              <div className="absolute inset-0 bg-grid-cyber opacity-35" />

              <svg className="w-full h-full" viewBox="0 0 1000 600">
                {/* Sector Outlines */}
                <rect x="40" y="30" width="440" height="250" rx="14" fill="rgba(6, 182, 212, 0.03)" stroke="rgba(6, 182, 212, 0.2)" strokeDasharray="3 3" />
                <rect x="520" y="30" width="440" height="250" rx="14" fill="rgba(14, 165, 233, 0.03)" stroke="rgba(14, 165, 233, 0.2)" strokeDasharray="3 3" />
                <rect x="40" y="320" width="440" height="250" rx="14" fill="rgba(16, 185, 129, 0.03)" stroke="rgba(16, 185, 129, 0.2)" strokeDasharray="3 3" />
                <rect x="520" y="320" width="440" height="250" rx="14" fill="rgba(244, 63, 94, 0.04)" stroke="rgba(244, 63, 94, 0.2)" strokeDasharray="3 3" />

                {/* Subsurface Pipe Connections */}
                <g strokeLinecap="round">
                  {/* Transmission Arterials */}
                  <line x1="220" y1="180" x2="380" y2="180" stroke="#00f2fe" strokeWidth="6" opacity="0.8" />
                  <line x1="380" y1="180" x2="720" y2="190" stroke="#00f2fe" strokeWidth="5" opacity="0.8" />
                  <line x1="720" y1="190" x2="820" y2="220" stroke="#00c6ff" strokeWidth="4" opacity="0.8" />
                  <line x1="380" y1="180" x2="280" y2="440" stroke="#38bdf8" strokeWidth="4" opacity="0.8" />
                  <line x1="280" y1="440" x2="180" y2="480" stroke="#38bdf8" strokeWidth="4" opacity="0.8" />
                  <line x1="380" y1="180" x2="550" y2="420" stroke="#f43f5e" strokeWidth="6" strokeDasharray="6 4" opacity="0.9" />
                  <line x1="550" y1="420" x2="680" y2="470" stroke="#f43f5e" strokeWidth="6" strokeDasharray="6 4" opacity="0.9" />
                </g>

                {/* Simulated Flow Particle Dots along pipes */}
                <circle cx="280" cy="180" r="3" fill="#ffffff">
                  <animate attributeName="cx" values="220;380" dur="3s" repeatCount="indefinite" />
                </circle>
                <circle cx="480" cy="184" r="3" fill="#ffffff">
                  <animate attributeName="cx" values="380;720" dur="4s" repeatCount="indefinite" />
                </circle>

                {/* Clickable Nodes */}
                {filteredNodes.map((node) => {
                  const cx = (node.x / 100) * 1000;
                  const cy = (node.y / 100) * 600;
                  const isSelected = selectedNode?.id === node.id;
                  const isDegraded = node.status === 'DEGRADED';

                  return (
                    <g
                      key={node.id}
                      onClick={() => onSelectNode(node)}
                      className="cursor-pointer group"
                    >
                      {/* Selection Ring */}
                      {isSelected && (
                        <circle
                          cx={cx}
                          cy={cy}
                          r={22}
                          fill="none"
                          stroke="#00f2fe"
                          strokeWidth="2"
                          strokeDasharray="4 2"
                        >
                          <animateTransform
                            attributeName="transform"
                            type="rotate"
                            from={`0 ${cx} ${cy}`}
                            to={`360 ${cx} ${cy}`}
                            dur="6s"
                            repeatCount="indefinite"
                          />
                        </circle>
                      )}

                      {/* Ripple Glow */}
                      <circle
                        cx={cx}
                        cy={cy}
                        r={isDegraded ? 16 : 12}
                        fill={isDegraded ? 'rgba(244, 63, 94, 0.35)' : 'rgba(6, 182, 212, 0.25)'}
                        className="group-hover:scale-125 transition-transform"
                      />

                      {/* Main Node Dot */}
                      <circle
                        cx={cx}
                        cy={cy}
                        r={isDegraded ? 9 : 7}
                        fill={isDegraded ? '#f43f5e' : '#00f2fe'}
                        stroke="#030712"
                        strokeWidth="2.5"
                      />

                      {/* Text Label */}
                      <text
                        x={cx}
                        y={cy - 16}
                        fill="#f1f5f9"
                        fontSize="11"
                        fontFamily="JetBrains Mono"
                        fontWeight="600"
                        textAnchor="middle"
                        className="pointer-events-none drop-shadow-md"
                      >
                        {node.name}
                      </text>

                      <text
                        x={cx}
                        y={cy + 22}
                        fill="#94a3b8"
                        fontSize="10"
                        fontFamily="JetBrains Mono"
                        textAnchor="middle"
                        className="pointer-events-none"
                      >
                        {node.readings.pressureBar} Bar | {node.readings.flowLps} L/s
                      </text>
                    </g>
                  );
                })}
              </svg>

              {/* Status helper at bottom */}
              <div className="absolute bottom-3 left-3 bg-navy-900/90 border border-cyan-500/20 rounded-lg px-3 py-1.5 text-[11px] font-mono text-slate-300 flex items-center gap-3">
                <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-cyan-400" /> Normal Main</span>
                <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-rose-500" /> Hydraulic Surge / Leak</span>
                <span className="text-slate-500">|</span>
                <span>Coordinates: UTM Zone 43N</span>
              </div>
            </div>
          </GlassCard>
        </div>

        {/* Right 1 Col: Selected Node Telemetry Drilldown */}
        <div>
          {selectedNode ? (
            <GlassCard
              title={selectedNode.name}
              subtitle={`Node ID: ${selectedNode.id.toUpperCase()} • Sector: ${selectedNode.zoneName}`}
              glow={selectedNode.status === 'DEGRADED' ? 'red' : 'cyan'}
              headerAction={
                <button
                  onClick={() => onSelectNode(null)}
                  className="p-1 rounded text-slate-400 hover:text-white"
                  title="Close Inspector"
                >
                  <X className="w-4 h-4" />
                </button>
              }
            >
              <div className="space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-cyan-500/15">
                  <span className="text-xs text-slate-400 font-mono">Operating Status</span>
                  <StatusBadge status={selectedNode.status} />
                </div>

                {/* Subterranean Physical Pipeline Attributes */}
                <div className="p-3 rounded-lg bg-navy-950/70 border border-cyan-500/10 space-y-2 text-xs font-mono">
                  <div className="text-[11px] font-semibold text-cyan-300 uppercase tracking-wider">
                    Pipe Specifications
                  </div>
                  <div className="flex justify-between text-slate-300">
                    <span>Material:</span>
                    <strong className="text-white">{selectedNode.pipeMaterial}</strong>
                  </div>
                  <div className="flex justify-between text-slate-300">
                    <span>Inner Diameter:</span>
                    <strong className="text-white">{selectedNode.pipeDiameterMm} mm</strong>
                  </div>
                  <div className="flex justify-between text-slate-300">
                    <span>Burial Depth:</span>
                    <strong className="text-white">{selectedNode.depthMeters} m below street</strong>
                  </div>
                  <div className="flex justify-between text-slate-300">
                    <span>Installed:</span>
                    <strong className="text-white">{selectedNode.installationYear} ({2026 - selectedNode.installationYear} yrs in service)</strong>
                  </div>
                </div>

                {/* Real-time Telemetry Metrics */}
                <div className="grid grid-cols-2 gap-2.5">
                  <div className="p-3 rounded-lg bg-navy-950/70 border border-cyan-500/15">
                    <span className="text-[10px] text-slate-400 font-mono block">Pressure</span>
                    <span className="text-lg font-bold font-mono text-cyan-300">
                      {selectedNode.readings.pressureBar} Bar
                    </span>
                    <span className="text-[10px] text-slate-500 block">Baseline: 4.5 Bar</span>
                  </div>

                  <div className="p-3 rounded-lg bg-navy-950/70 border border-cyan-500/15">
                    <span className="text-[10px] text-slate-400 font-mono block">Flow Rate</span>
                    <span className="text-lg font-bold font-mono text-sky-300">
                      {selectedNode.readings.flowLps} L/s
                    </span>
                    <span className="text-[10px] text-slate-500 block">Ultrasonic meter</span>
                  </div>

                  <div className="p-3 rounded-lg bg-navy-950/70 border border-cyan-500/15">
                    <span className="text-[10px] text-slate-400 font-mono block">Acoustic Vibration</span>
                    <span className={`text-lg font-bold font-mono ${selectedNode.readings.acousticDb > 50 ? 'text-rose-400' : 'text-emerald-400'}`}>
                      {selectedNode.readings.acousticDb} dB
                    </span>
                    <span className="text-[10px] text-slate-500 block">Threshold: 45 dB</span>
                  </div>

                  <div className="p-3 rounded-lg bg-navy-950/70 border border-cyan-500/15">
                    <span className="text-[10px] text-slate-400 font-mono block">Water Quality pH</span>
                    <span className="text-lg font-bold font-mono text-emerald-300">
                      {selectedNode.readings.ph}
                    </span>
                    <span className="text-[10px] text-slate-500 block">Nominal: 6.5 - 8.5</span>
                  </div>
                </div>

                {/* IoT Node Health */}
                <div className="p-3 rounded-lg bg-navy-950/70 border border-cyan-500/15 text-xs font-mono space-y-1.5">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Battery Level:</span>
                    <span className="text-emerald-400 font-bold">{selectedNode.batteryLevel}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Signal RSSI:</span>
                    <span className="text-slate-200">{selectedNode.rssi} dBm (LoRaWAN 868MHz)</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Last Ping:</span>
                    <span className="text-cyan-300">{selectedNode.lastTelemetryTime}</span>
                  </div>
                </div>
              </div>
            </GlassCard>
          ) : (
            <GlassCard
              title="Sensor Node Directory"
              subtitle="Select a node from map or list to inspect"
            >
              <div className="space-y-2 max-h-[420px] overflow-y-auto pr-1">
                {filteredNodes.map((node) => (
                  <div
                    key={node.id}
                    onClick={() => onSelectNode(node)}
                    className="p-3 rounded-xl bg-navy-850/60 border border-cyan-500/10 hover:border-cyan-500/30 cursor-pointer transition-colors flex items-center justify-between"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-display font-semibold text-xs text-white">
                          {node.name}
                        </span>
                        <span className="text-[10px] font-mono text-slate-400">
                          #{node.id}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 font-sans mt-0.5">
                        {node.zoneName} • {node.pipeDiameterMm}mm {node.pipeMaterial}
                      </p>
                    </div>

                    <div className="text-right font-mono">
                      <div className="text-xs font-bold text-cyan-300">
                        {node.readings.pressureBar} Bar
                      </div>
                      <div className="text-[10px] text-slate-400">
                        {node.readings.flowLps} L/s
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </GlassCard>
          )}
        </div>
      </div>
    </div>
  );
};
