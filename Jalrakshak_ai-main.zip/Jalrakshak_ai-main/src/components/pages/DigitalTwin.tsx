import React, { useState } from 'react';
import { 
  Boxes, 
  Play, 
  RotateCcw, 
  Activity, 
  Zap, 
  Sliders, 
  Flame, 
  Droplet, 
  ShieldCheck, 
  AlertCircle,
  HelpCircle
} from 'lucide-react';
import { GlassCard } from '../common/GlassCard';
import { SensorNode } from '../../types/pipeline';

interface DigitalTwinProps {
  nodes: SensorNode[];
  onInjectSurge: (nodeId: string, surgeBar: number) => void;
}

export const DigitalTwin: React.FC<DigitalTwinProps> = ({ nodes, onInjectSurge }) => {
  const [selectedNodeId, setSelectedNodeId] = useState<string>('node-s02');
  const [simulatedSurge, setSimulatedSurge] = useState<number>(2.5);
  const [hasLeak, setHasLeak] = useState<boolean>(false);
  const [flowSpeedMultiplier, setFlowSpeedMultiplier] = useState<number>(1);
  const [viewMode, setViewMode] = useState<'cross-section' | 'isometric' | 'pressure-gradient'>('cross-section');
  const [lastActionMessage, setLastActionMessage] = useState<string>('Digital Twin synchronized with live SCADA mesh telemetry.');

  const targetNode = nodes.find((n) => n.id === selectedNodeId) || nodes[0];

  const handleTriggerSurge = () => {
    onInjectSurge(targetNode.id, simulatedSurge);
    setLastActionMessage(`Simulated Water Hammer pulse of +${simulatedSurge} Bar injected into Digital Twin. Attenuation verified.`);
  };

  const handleToggleLeak = () => {
    const nextLeak = !hasLeak;
    setHasLeak(nextLeak);
    if (nextLeak) {
      onInjectSurge(targetNode.id, -1.8);
      setLastActionMessage('Simulated sub-surface wall breach injected. Acoustic hydrophone spike triggered.');
    } else {
      setLastActionMessage('Pipe wall breach sealed in digital twin. Hydrostatic equilibrium restored.');
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Top Controls & Status Bar */}
      <div className="p-4 rounded-xl bg-navy-900/80 border border-cyan-500/20 backdrop-blur-md flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-4 flex-wrap">
          <div className="flex items-center gap-2 text-xs font-mono text-cyan-300">
            <Boxes className="w-4 h-4 text-cyan-400" />
            <span>TWIN FIDELITY: <strong className="text-white">99.8%</strong> (42ms SCADA LAG)</span>
          </div>

          <div className="h-4 w-[1px] bg-slate-700 hidden sm:block" />

          {/* Monitored node selector */}
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono text-slate-400">TARGET PIPE SEGMENT:</span>
            <select
              value={selectedNodeId}
              onChange={(e) => setSelectedNodeId(e.target.value)}
              className="bg-navy-950 border border-cyan-500/30 rounded-lg px-3 py-1 text-xs font-mono text-cyan-300 font-semibold focus:outline-none"
            >
              {nodes.map((n) => (
                <option key={n.id} value={n.id}>
                  {n.name} ({n.pipeDiameterMm}mm {n.pipeMaterial})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* View Mode Toggle */}
        <div className="flex items-center gap-1 bg-navy-950 p-1 rounded-lg border border-cyan-500/20 text-xs font-mono">
          <button
            onClick={() => setViewMode('cross-section')}
            className={`px-3 py-1 rounded transition-colors ${
              viewMode === 'cross-section' ? 'bg-cyan-500 text-navy-950 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            Subsurface Cross-Section
          </button>
          <button
            onClick={() => setViewMode('isometric')}
            className={`px-3 py-1 rounded transition-colors ${
              viewMode === 'isometric' ? 'bg-cyan-500 text-navy-950 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            Isometric Flow
          </button>
          <button
            onClick={() => setViewMode('pressure-gradient')}
            className={`px-3 py-1 rounded transition-colors ${
              viewMode === 'pressure-gradient' ? 'bg-cyan-500 text-navy-950 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            Pressure Gradient
          </button>
        </div>
      </div>

      {/* Main Digital Twin Interactive Visualizer */}
      <GlassCard
        title={`Underground Pipeline Digital Twin: ${targetNode.name}`}
        subtitle={`Depth: ${targetNode.depthMeters}m • Diameter: ${targetNode.pipeDiameterMm}mm ${targetNode.pipeMaterial}`}
        glow={hasLeak ? 'red' : 'cyan'}
        headerAction={
          <div className="flex items-center gap-2 text-xs font-mono">
            <span className="text-slate-400">Real-time Pressure:</span>
            <strong className="text-cyan-300">{targetNode.readings.pressureBar} Bar</strong>
          </div>
        }
      >
        <div className="relative w-full h-[400px] rounded-xl bg-navy-950 border border-cyan-500/25 overflow-hidden flex items-center justify-center">
          {/* Subterranean Geological Soil Strata Layers */}
          <div className="absolute inset-0 flex flex-col pointer-events-none opacity-40">
            <div className="h-1/4 bg-amber-950/20 border-b border-amber-900/30">
              <span className="text-[10px] font-mono text-amber-500/60 p-2 block">Street Level Asphalt & Fill (0.0m - 0.8m)</span>
            </div>
            <div className="h-2/4 bg-yellow-950/20 border-b border-yellow-900/30">
              <span className="text-[10px] font-mono text-yellow-500/60 p-2 block">Silty Clay & Dense Sand Bedding ({targetNode.depthMeters}m Underground)</span>
            </div>
            <div className="h-1/4 bg-slate-900/40">
              <span className="text-[10px] font-mono text-slate-500/60 p-2 block">Bedrock Formation & Groundwater Aquifer Table</span>
            </div>
          </div>

          {/* SVG Pipeline Canvas */}
          <svg className="w-full h-full relative z-10" viewBox="0 0 900 400">
            <defs>
              {/* Pipe Metal Gradient */}
              <linearGradient id="pipeMetal" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#1e293b" />
                <stop offset="50%" stopColor="#334155" />
                <stop offset="100%" stopColor="#0f172a" />
              </linearGradient>

              {/* Water Core Gradient */}
              <linearGradient id="waterFlow" x1="0" y1="0" x2="1" y2="0">
                <stop offset="0%" stopColor="#0284c7" />
                <stop offset="50%" stopColor="#00f2fe" />
                <stop offset="100%" stopColor="#0369a1" />
              </linearGradient>

              {/* High Surge Gradient */}
              <linearGradient id="waterSurge" x1="0" y1="0" x2="1" y2="0">
                <stop offset="0%" stopColor="#f43f5e" />
                <stop offset="50%" stopColor="#f59e0b" />
                <stop offset="100%" stopColor="#00f2fe" />
              </linearGradient>
            </defs>

            {/* Pipeline Outer Wall */}
            <rect x="100" y="140" width="700" height="120" rx="8" fill="url(#pipeMetal)" stroke="#00f2fe" strokeWidth="2" opacity="0.9" />

            {/* Inner Water Channel */}
            <rect
              x="100"
              y="155"
              width="700"
              height="90"
              fill={hasLeak ? 'url(#waterSurge)' : 'url(#waterFlow)'}
              opacity="0.85"
            />

            {/* Animated Flow Velocity Streamlines */}
            <g stroke="#ffffff" strokeWidth="2" strokeDasharray="15 25" opacity="0.65">
              <line x1="100" y1="175" x2="800" y2="175">
                <animate attributeName="stroke-dashoffset" values="400;0" dur={`${4 / flowSpeedMultiplier}s`} repeatCount="indefinite" />
              </line>
              <line x1="100" y1="200" x2="800" y2="200">
                <animate attributeName="stroke-dashoffset" values="400;0" dur={`${3 / flowSpeedMultiplier}s`} repeatCount="indefinite" />
              </line>
              <line x1="100" y1="225" x2="800" y2="225">
                <animate attributeName="stroke-dashoffset" values="400;0" dur={`${4.5 / flowSpeedMultiplier}s`} repeatCount="indefinite" />
              </line>
            </g>

            {/* Ultrasonic & Hydrophone Sensor Clamped to Wall */}
            <g transform="translate(420, 100)">
              <rect x="0" y="0" width="60" height="40" rx="6" fill="#070d1e" stroke="#00f2fe" strokeWidth="2" />
              <circle cx="30" cy="20" r="8" fill="#00f2fe" />
              <line x1="30" y1="40" x2="30" y2="55" stroke="#00f2fe" strokeWidth="3" />
              <text x="30" y="-8" fill="#00f2fe" fontSize="10" fontFamily="JetBrains Mono" textAnchor="middle" fontWeight="bold">
                HYDROPHONE
              </text>
            </g>

            {/* Pressure Relief Valve (PRV) */}
            <g transform="translate(680, 80)">
              <polygon points="0,60 25,20 50,60" fill="#0f172a" stroke="#38bdf8" strokeWidth="2" />
              <rect x="20" y="0" width="10" height="20" fill="#38bdf8" />
              <circle cx="25" cy="0" r="14" fill="#0284c7" stroke="#38bdf8" strokeWidth="2" />
              <text x="25" y="-18" fill="#38bdf8" fontSize="10" fontFamily="JetBrains Mono" textAnchor="middle" fontWeight="bold">
                AUTO PRV-09
              </text>
            </g>

            {/* Simulated Micro-Leak Spray if active */}
            {hasLeak && (
              <g transform="translate(560, 140)">
                <circle cx="0" cy="0" r="6" fill="#f43f5e" />
                <path d="M 0 0 C 10 -40, 30 -60, 50 -80" fill="none" stroke="#38bdf8" strokeWidth="3" strokeDasharray="4 2">
                  <animate attributeName="stroke-dashoffset" values="20;0" dur="0.4s" repeatCount="indefinite" />
                </path>
                <circle cx="50" cy="-80" r="12" fill="rgba(56, 189, 248, 0.4)">
                  <animate attributeName="r" values="4;18" dur="0.6s" repeatCount="indefinite" />
                  <animate attributeName="opacity" values="0.8;0" dur="0.6s" repeatCount="indefinite" />
                </circle>
                <text x="70" y="-70" fill="#f43f5e" fontSize="11" fontFamily="JetBrains Mono" fontWeight="bold">
                  ACTIVE FRACTURE (120 L/min)
                </text>
              </g>
            )}

            {/* Subsurface Measurement Annotations */}
            <text x="120" y="130" fill="#94a3b8" fontSize="11" fontFamily="JetBrains Mono">
              INLET FLOW: {targetNode.readings.flowLps} L/s
            </text>
            <text x="760" y="280" fill="#94a3b8" fontSize="11" fontFamily="JetBrains Mono" textAnchor="end">
              INTERNAL PRESSURE: {targetNode.readings.pressureBar} BAR
            </text>
          </svg>

          {/* Action notification toast */}
          <div className="absolute bottom-3 left-3 right-3 bg-navy-900/90 border border-cyan-500/30 rounded-lg p-2 text-xs font-mono text-cyan-300 flex items-center justify-between">
            <span>{lastActionMessage}</span>
            <span className="text-[10px] text-slate-400">PHYSICS ENGINE: ACTIVE</span>
          </div>
        </div>
      </GlassCard>

      {/* Interactive Simulation Sandbox Controls */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Stress Injection Controls */}
        <div className="lg:col-span-2">
          <GlassCard
            title="Hydraulic Stress Injection Simulator"
            subtitle="Test subterranean system resilience against sudden pressure surges and fractures"
            glow="amber"
          >
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Surge injection tool */}
              <div className="p-4 rounded-xl bg-navy-950/70 border border-cyan-500/20 space-y-3">
                <div className="flex items-center gap-2 text-amber-400 font-mono text-xs font-semibold">
                  <Flame className="w-4 h-4" />
                  <span>WATER HAMMER PULSE</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed font-sans">
                  Simulate a rapid valve closure or sudden pump trip to produce a transient hydraulic shockwave.
                </p>

                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-mono text-slate-300">
                    <span>Transient Amplitude:</span>
                    <strong className="text-amber-300">+{simulatedSurge} Bar</strong>
                  </div>
                  <input
                    type="range"
                    min="0.5"
                    max="5.0"
                    step="0.5"
                    value={simulatedSurge}
                    onChange={(e) => setSimulatedSurge(parseFloat(e.target.value))}
                    className="w-full accent-amber-400 cursor-pointer"
                  />
                </div>

                <button
                  onClick={handleTriggerSurge}
                  className="w-full py-2 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-mono font-bold uppercase transition-colors"
                >
                  Inject Shockwave Pulse
                </button>
              </div>

              {/* Micro-leak fracture injector */}
              <div className="p-4 rounded-xl bg-navy-950/70 border border-cyan-500/20 space-y-3">
                <div className="flex items-center gap-2 text-rose-400 font-mono text-xs font-semibold">
                  <Droplet className="w-4 h-4" />
                  <span>WALL PUNCTURE BREACH</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed font-sans">
                  Inject a simulated 15mm wall fissure to verify hydrophone acoustic cross-correlation detection speed.
                </p>

                <div className="flex items-center justify-between text-xs font-mono text-slate-300 pt-2">
                  <span>Fracture State:</span>
                  <span className={`font-bold ${hasLeak ? 'text-rose-400' : 'text-emerald-400'}`}>
                    {hasLeak ? 'ACTIVE RUPTURE' : 'SEALED'}
                  </span>
                </div>

                <button
                  onClick={handleToggleLeak}
                  className={`w-full py-2 rounded-lg text-xs font-mono font-bold uppercase transition-colors border ${
                    hasLeak
                      ? 'bg-rose-500 text-white border-rose-400 animate-pulse'
                      : 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40 hover:bg-cyan-500/30'
                  }`}
                >
                  {hasLeak ? 'Seal Simulated Breach' : 'Trigger Subsurface Fracture'}
                </button>
              </div>
            </div>
          </GlassCard>
        </div>

        {/* Right 1 Col: Dynamic Twin Parameters */}
        <GlassCard
          title="Hydrodynamic Twin Metrics"
          subtitle="Real-time Navier-Stokes fluid parameters"
        >
          <div className="space-y-3 font-mono text-xs text-slate-300">
            <div className="p-2.5 rounded-lg bg-navy-950/70 border border-cyan-500/15 flex justify-between">
              <span className="text-slate-400">Reynolds Number (Re):</span>
              <strong className="text-cyan-300">42,800 (Turbulent Flow)</strong>
            </div>

            <div className="p-2.5 rounded-lg bg-navy-950/70 border border-cyan-500/15 flex justify-between">
              <span className="text-slate-400">Hazen-Williams C:</span>
              <strong className="text-white">130 (Ductile Iron)</strong>
            </div>

            <div className="p-2.5 rounded-lg bg-navy-950/70 border border-cyan-500/15 flex justify-between">
              <span className="text-slate-400">Wave Speed (a):</span>
              <strong className="text-white">1,120 m/s</strong>
            </div>

            <div className="p-2.5 rounded-lg bg-navy-950/70 border border-cyan-500/15 flex justify-between">
              <span className="text-slate-400">PRV Response Latency:</span>
              <strong className="text-emerald-400">180 ms</strong>
            </div>

            <div className="p-2.5 rounded-lg bg-navy-950/70 border border-cyan-500/15 flex justify-between">
              <span className="text-slate-400">Soil Moisture Coupling:</span>
              <strong className="text-slate-200">18.4% Volumetric</strong>
            </div>
          </div>
        </GlassCard>
      </div>
    </div>
  );
};
