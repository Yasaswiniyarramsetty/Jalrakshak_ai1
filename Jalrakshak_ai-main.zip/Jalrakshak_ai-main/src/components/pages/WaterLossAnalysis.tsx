import React, { useState } from 'react';
import { 
  Droplets, 
  TrendingDown, 
  IndianRupee, 
  Target, 
  Activity, 
  ShieldCheck, 
  BarChart3, 
  Search,
  Zap
} from 'lucide-react';
import { GlassCard } from '../common/GlassCard';
import { StatCard } from '../common/StatCard';
import { WaterAuditStats } from '../../types/pipeline';

interface WaterLossAnalysisProps {
  auditStats: WaterAuditStats;
}

export const WaterLossAnalysis: React.FC<WaterLossAnalysisProps> = ({ auditStats }) => {
  const [pipeDistanceMeters, setPipeDistanceMeters] = useState<number>(140);
  const [timeDiffMs, setTimeDiffMs] = useState<number>(36);

  // Speed of acoustic sound wave in water-filled ductile iron pipe ≈ 1,200 m/s
  // Leak distance from Sensor 1: L1 = (D - v * Δt) / 2
  const soundVelocity = 1200; // m/s
  const deltaDistance = (soundVelocity * (timeDiffMs / 1000));
  const leakOffsetFromA = Math.max(0, Math.min(pipeDistanceMeters, Number(((pipeDistanceMeters - deltaDistance) / 2).toFixed(1))));

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Top Banner */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-navy-900/90 via-navy-850/90 to-cyan-950/40 border border-cyan-500/20 backdrop-blur-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2 py-0.5 rounded text-[11px] font-mono font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-400/30">
              IWA / AWWA STANDARD WATER BALANCE AUDIT
            </span>
            <span className="text-xs font-mono text-emerald-400">
              CITY WATER LOSS BENCHMARK: TOP 5% TIER
            </span>
          </div>
          <h2 className="text-2xl font-bold font-display text-white">
            Non-Revenue Water (NRW) & Acoustic Conservation
          </h2>
          <p className="text-xs text-slate-300 mt-1 max-w-2xl">
            Real-time tracking of physical leak volume, pressure-managed leakage reductions, and subterranean acoustic pinpointing to prevent non-revenue losses.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="p-3 rounded-xl bg-navy-950/80 border border-emerald-500/30 text-right font-mono">
            <span className="text-[10px] text-slate-400 block">TOTAL RECOVERED VALUE</span>
            <span className="text-xl font-bold text-emerald-400">₹{(auditStats.costSavedInr / 10000000).toFixed(2)} Cr</span>
          </div>
        </div>
      </div>

      {/* KPI Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Current NRW Rate"
          value={auditStats.nrwPercentage}
          unit="%"
          change={-3.8}
          changeLabel="Target: < 10.0%"
          icon={<Droplets className="w-5 h-5" />}
          accent="cyan"
          subtitle="Industry national average: 28-35%"
        />
        <StatCard
          title="Physical Leaks Pinpointed"
          value={auditStats.acousticLeaksFound}
          unit="Sites"
          change={12}
          changeLabel="100% fixed < 48h"
          icon={<Target className="w-5 h-5" />}
          accent="emerald"
          subtitle="Hydrophone acoustic correlation"
        />
        <StatCard
          title="Water Preserved"
          value={(auditStats.physicalLossSavedM3 / 1000).toFixed(1)}
          unit="ML"
          change={18.4}
          changeLabel="Million Liters saved"
          icon={<TrendingDown className="w-5 h-5" />}
          accent="blue"
          subtitle="Equivalent to 57,000 households"
        />
        <StatCard
          title="Financial Loss Avoided"
          value="2.85"
          unit="₹ Cr"
          change={24.2}
          changeLabel="Pumping energy + treated water"
          icon={<IndianRupee className="w-5 h-5" />}
          accent="emerald"
          subtitle="Municipal revenue safeguarded"
        />
      </div>

      {/* Main Grid: Acoustic Correlation Pinpointer & Water Balance Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Acoustic Correlation Pinpointer Tool */}
        <GlassCard
          title="Acoustic Hydrophone Leak Pinpointing Engine"
          subtitle="Sub-meter mathematical localization using differential time-of-arrival (TDOA)"
          glow="cyan"
        >
          <div className="space-y-4">
            <div className="p-3 rounded-xl bg-navy-950/70 border border-cyan-500/20 text-xs text-slate-300 leading-relaxed font-sans">
              Hydrophones at adjacent sensor nodes detect subterranean rupture noise. By measuring wave velocity (1,200 m/s) and microsecond time offset, the system localizes the underground breach without road excavation.
            </div>

            {/* Slider controls */}
            <div className="space-y-3 font-mono text-xs">
              <div className="space-y-1">
                <div className="flex justify-between text-slate-300">
                  <span>Distance Between Node A & B:</span>
                  <strong className="text-cyan-300">{pipeDistanceMeters} Meters</strong>
                </div>
                <input
                  type="range"
                  min="50"
                  max="300"
                  step="10"
                  value={pipeDistanceMeters}
                  onChange={(e) => setPipeDistanceMeters(parseInt(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-slate-300">
                  <span>Acoustic Arrival Time Delta (Δt):</span>
                  <strong className="text-amber-300">{timeDiffMs} ms</strong>
                </div>
                <input
                  type="range"
                  min="0"
                  max="80"
                  step="2"
                  value={timeDiffMs}
                  onChange={(e) => setTimeDiffMs(parseInt(e.target.value))}
                  className="w-full accent-amber-400 cursor-pointer"
                />
              </div>
            </div>

            {/* Interactive Visual Graphic of the Pipeline Span */}
            <div className="p-4 rounded-xl bg-navy-950 border border-cyan-500/25 space-y-3">
              <div className="flex justify-between items-center text-xs font-mono text-slate-300">
                <span className="text-cyan-400 font-bold">NODE A (Hydrophone 1)</span>
                <span className="text-sky-400 font-bold">NODE B (Hydrophone 2)</span>
              </div>

              {/* Pipeline bar with leak indicator */}
              <div className="relative w-full h-8 bg-slate-800 rounded-lg overflow-hidden flex items-center px-1">
                <div className="w-full h-3 bg-gradient-to-r from-cyan-500 via-sky-500 to-cyan-500 rounded" />

                {/* Leak marker dot */}
                <div
                  className="absolute top-0 bottom-0 flex flex-col items-center justify-center transition-all duration-300"
                  style={{ left: `${(leakOffsetFromA / pipeDistanceMeters) * 100}%` }}
                >
                  <div className="w-4 h-4 rounded-full bg-rose-500 border-2 border-white shadow-glow-red animate-ping" />
                  <div className="w-2 h-2 rounded-full bg-rose-500 absolute" />
                </div>
              </div>

              {/* Distance readout */}
              <div className="p-3 rounded-lg bg-rose-950/30 border border-rose-500/30 flex items-center justify-between text-xs font-mono">
                <span className="text-rose-300">PINPOINTED LEAK LOCATION:</span>
                <span className="text-sm font-bold text-white">
                  {leakOffsetFromA} m from Node A ({pipeDistanceMeters - leakOffsetFromA} m from Node B)
                </span>
              </div>
            </div>
          </div>
        </GlassCard>

        {/* IWA Standard Water Balance Breakdown */}
        <GlassCard
          title="System Water Balance (IWA Standard)"
          subtitle="Monthly municipal supply vs authorized billed volume"
        >
          <div className="space-y-4 font-mono text-xs">
            {/* System Input */}
            <div className="p-3.5 rounded-xl bg-navy-950/70 border border-cyan-500/20">
              <div className="flex justify-between text-slate-300 mb-1">
                <span className="text-cyan-300 font-semibold">Total System Input Volume</span>
                <strong className="text-white">{auditStats.totalSuppliedM3.toLocaleString()} m³ (100%)</strong>
              </div>
              <div className="w-full bg-navy-900 h-2.5 rounded-full overflow-hidden">
                <div className="bg-cyan-400 h-full w-full" />
              </div>
            </div>

            {/* Billed Authorized */}
            <div className="p-3.5 rounded-xl bg-navy-950/70 border border-cyan-500/20">
              <div className="flex justify-between text-slate-300 mb-1">
                <span className="text-emerald-300 font-semibold">Billed Authorized Consumption</span>
                <strong className="text-white">{auditStats.totalBilledM3.toLocaleString()} m³ (92.8%)</strong>
              </div>
              <div className="w-full bg-navy-900 h-2.5 rounded-full overflow-hidden">
                <div className="bg-emerald-400 h-full w-[92.8%]" />
              </div>
              <p className="text-[10px] text-slate-400 mt-1 font-sans">
                Domestic smart meters + commercial billing revenue streams.
              </p>
            </div>

            {/* Non-Revenue Water Breakdown */}
            <div className="p-3.5 rounded-xl bg-rose-950/20 border border-rose-500/20 space-y-2">
              <div className="flex justify-between text-slate-300 mb-1">
                <span className="text-rose-400 font-semibold">Non-Revenue Water (Loss)</span>
                <strong className="text-rose-300">{auditStats.nonRevenueWaterM3.toLocaleString()} m³ (7.2%)</strong>
              </div>
              <div className="w-full bg-navy-900 h-2.5 rounded-full overflow-hidden">
                <div className="bg-rose-500 h-full w-[7.2%]" />
              </div>

              <div className="grid grid-cols-2 gap-2 pt-2 text-[11px]">
                <div className="p-2 rounded bg-navy-950/70 border border-rose-500/20">
                  <span className="text-slate-400 block">Real Losses (Physical):</span>
                  <strong className="text-white">65% (Buried leaks & bursts)</strong>
                </div>
                <div className="p-2 rounded bg-navy-950/70 border border-rose-500/20">
                  <span className="text-slate-400 block">Apparent Losses:</span>
                  <strong className="text-white">35% (Meter slip & illegal)</strong>
                </div>
              </div>
            </div>
          </div>
        </GlassCard>
      </div>
    </div>
  );
};
