import React, { useState } from 'react';
import { 
  BrainCircuit, 
  AlertTriangle, 
  Clock, 
  Sparkles, 
  TrendingUp, 
  ShieldAlert, 
  Layers, 
  Cpu, 
  CheckCircle,
  HelpCircle,
  Wrench
} from 'lucide-react';
import { GlassCard } from '../common/GlassCard';
import { AiPrediction } from '../../types/pipeline';

interface AiPredictionsProps {
  predictions: AiPrediction[];
}

export const AiPredictions: React.FC<AiPredictionsProps> = ({ predictions }) => {
  const [selectedPrediction, setSelectedPrediction] = useState<AiPrediction>(predictions[0]);

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header Banner */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-navy-900/90 via-navy-850/90 to-cyan-950/40 border border-cyan-500/20 backdrop-blur-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2 py-0.5 rounded text-[11px] font-mono font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-400/30">
              PHYSICS-INFORMED NEURAL NETWORK (PINN)
            </span>
            <span className="text-xs font-mono text-slate-400">
              AI MODEL v4.2 • EPANET HYDRAULIC HYBRID
            </span>
          </div>
          <h2 className="text-2xl font-bold font-display text-white">
            Underground Pipeline Failure Risk & Life Expectancy
          </h2>
          <p className="text-xs text-slate-300 mt-1 max-w-2xl">
            Correlating sub-surface acoustic vibrations, transient water hammer pressure spikes, soil electrochemistry, and historical fatigue cycles to preempt catastrophic pipeline bursts.
          </p>
        </div>

        <div className="flex items-center gap-4 text-xs font-mono">
          <div className="p-3 rounded-xl bg-navy-950/80 border border-cyan-500/20">
            <span className="text-slate-400 block text-[10px]">PREDICTIVE ACCURACY</span>
            <span className="text-lg font-bold text-cyan-300">96.8%</span>
          </div>
          <div className="p-3 rounded-xl bg-navy-950/80 border border-cyan-500/20">
            <span className="text-slate-400 block text-[10px]">PREEMPTED BURSTS (YTD)</span>
            <span className="text-lg font-bold text-emerald-400">14 Major</span>
          </div>
        </div>
      </div>

      {/* Main Grid: Pipeline Segments Risk Table & Model Drilldown */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Predicted Risk Ranking */}
        <div className="lg:col-span-2 space-y-4">
          <GlassCard
            title="Subterranean Segment Risk Assessment"
            subtitle="Ranked by Machine Learning failure probability score"
            glow="cyan"
          >
            <div className="space-y-3">
              {predictions.map((pred) => {
                const isSelected = selectedPrediction.id === pred.id;
                const isExtreme = pred.riskLevel === 'EXTREME';
                const isHigh = pred.riskLevel === 'HIGH';

                return (
                  <div
                    key={pred.id}
                    onClick={() => setSelectedPrediction(pred)}
                    className={`p-4 rounded-xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-navy-850 border-cyan-400/50 shadow-glow-cyan'
                        : 'bg-navy-900/60 border-cyan-500/10 hover:border-cyan-500/30'
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-display font-semibold text-sm text-white">
                            {pred.segmentName}
                          </span>
                          <span className="text-xs font-mono text-slate-400">
                            #{pred.segmentId}
                          </span>
                        </div>
                        <span className="text-xs text-slate-400">
                          Zone: <strong className="text-cyan-300">{pred.zoneName}</strong>
                        </span>
                      </div>

                      <div className="flex items-center gap-3">
                        <div className="text-right font-mono">
                          <span className="text-xs text-slate-400 block">RUL</span>
                          <span className={`text-sm font-bold ${pred.remainingUsefulLifeMonths < 12 ? 'text-rose-400' : 'text-emerald-400'}`}>
                            {pred.remainingUsefulLifeMonths} Months
                          </span>
                        </div>

                        <span
                          className={`px-2.5 py-1 rounded-lg text-xs font-mono font-bold uppercase tracking-wider ${
                            isExtreme
                              ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 animate-pulse'
                              : isHigh
                              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                              : 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                          }`}
                        >
                          Risk: {pred.burstRiskScore}%
                        </span>
                      </div>
                    </div>

                    {/* Risk progress bar */}
                    <div className="w-full bg-navy-950 h-2 rounded-full overflow-hidden mb-2">
                      <div
                        className={`h-full rounded-full transition-all duration-500 ${
                          isExtreme
                            ? 'bg-gradient-to-r from-amber-500 to-rose-500'
                            : isHigh
                            ? 'bg-gradient-to-r from-cyan-400 to-amber-500'
                            : 'bg-cyan-400'
                        }`}
                        style={{ width: `${pred.burstRiskScore}%` }}
                      />
                    </div>

                    <div className="flex flex-wrap items-center justify-between text-xs font-mono text-slate-400">
                      <span>Transient Stress: <strong className={pred.transientVulnerability === 'CRITICAL' ? 'text-rose-400' : 'text-slate-200'}>{pred.transientVulnerability}</strong></span>
                      <span>Degradation: <strong className="text-slate-200">+{pred.degradationRatePercent}% / yr</strong></span>
                      <span>Simulated Surge: <strong className="text-cyan-300">{pred.lastSimulatedHammerBar} Bar</strong></span>
                    </div>
                  </div>
                );
              })}
            </div>
          </GlassCard>

          {/* Explainable AI (XAI) Feature Importance */}
          <GlassCard
            title="Explainable AI: Risk Feature Weights"
            subtitle="Parameters driving PINN model failure probability output"
          >
            <div className="space-y-3 font-mono text-xs">
              <div>
                <div className="flex justify-between text-slate-300 mb-1">
                  <span>Hydraulic Pressure Transient Peaks (Water Hammer)</span>
                  <strong className="text-cyan-300">42% Weight</strong>
                </div>
                <div className="w-full bg-navy-950 h-2 rounded-full overflow-hidden">
                  <div className="bg-cyan-400 h-full w-[42%]" />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-slate-300 mb-1">
                  <span>Sub-surface Acoustic Vibration Anomaly Resonance</span>
                  <strong className="text-sky-300">28% Weight</strong>
                </div>
                <div className="w-full bg-navy-950 h-2 rounded-full overflow-hidden">
                  <div className="bg-sky-400 h-full w-[28%]" />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-slate-300 mb-1">
                  <span>Pipe Age & Wall Loss Cathodic Factor</span>
                  <strong className="text-amber-300">18% Weight</strong>
                </div>
                <div className="w-full bg-navy-950 h-2 rounded-full overflow-hidden">
                  <div className="bg-amber-400 h-full w-[18%]" />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-slate-300 mb-1">
                  <span>Soil Moisture Shift & Heavy Traffic Cyclic Loading</span>
                  <strong className="text-emerald-300">12% Weight</strong>
                </div>
                <div className="w-full bg-navy-950 h-2 rounded-full overflow-hidden">
                  <div className="bg-emerald-400 h-full w-[12%]" />
                </div>
              </div>
            </div>
          </GlassCard>
        </div>

        {/* Right 1 Col: Selected Segment AI Recommendation & Prescription */}
        <div className="space-y-4">
          <GlassCard
            title="AI Maintenance Prescription"
            subtitle={`Target: ${selectedPrediction.segmentName}`}
            glow={selectedPrediction.riskLevel === 'EXTREME' ? 'red' : 'cyan'}
          >
            <div className="space-y-4">
              <div className="p-3.5 rounded-xl bg-navy-950/80 border border-cyan-500/20">
                <span className="text-[10px] font-mono text-cyan-400 uppercase tracking-wider block mb-1">
                  Primary Root Cause Stress Factor
                </span>
                <p className="text-xs text-slate-200 leading-relaxed font-sans">
                  {selectedPrediction.primaryStressFactor}
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-cyan-950/30 border border-cyan-400/30">
                <div className="flex items-center gap-2 text-cyan-300 font-mono text-xs font-semibold mb-1.5">
                  <Sparkles className="w-4 h-4 text-cyan-400" />
                  <span>PRESCRIBED REMEDIATION</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed font-sans">
                  {selectedPrediction.recommendation}
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-navy-950/80 border border-cyan-500/20 space-y-2 text-xs font-mono">
                <div className="flex justify-between">
                  <span className="text-slate-400">Current Burst Risk:</span>
                  <span className={`font-bold ${selectedPrediction.burstRiskScore > 70 ? 'text-rose-400' : 'text-emerald-400'}`}>
                    {selectedPrediction.burstRiskScore}% ({selectedPrediction.riskLevel})
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Remaining Useful Life:</span>
                  <span className="text-white font-bold">{selectedPrediction.remainingUsefulLifeMonths} Months</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Degradation Velocity:</span>
                  <span className="text-slate-200">+{selectedPrediction.degradationRatePercent}% / yr</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Peak Surge Resistance:</span>
                  <span className="text-cyan-300">{selectedPrediction.lastSimulatedHammerBar} Bar Limit</span>
                </div>
              </div>

              <button
                onClick={() => alert(`Maintenance work order generated for ${selectedPrediction.segmentName}. Ticket dispatched to Municipal SCADA Asset Management.`)}
                className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-sky-600 hover:from-cyan-400 hover:to-sky-500 text-navy-950 font-semibold text-xs font-mono tracking-wider uppercase transition-all shadow-glow-cyan"
              >
                <Wrench className="w-4 h-4" />
                <span>Generate Preventative Work Order</span>
              </button>
            </div>
          </GlassCard>

          {/* Machine Learning Model Metrics */}
          <GlassCard title="PINN Hybrid Architecture">
            <div className="text-xs font-mono text-slate-300 space-y-2">
              <div className="flex justify-between">
                <span className="text-slate-400">Hydraulic Solver:</span>
                <span className="text-cyan-300">EPANET 2.2 Dynamic</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Neural Network:</span>
                <span className="text-slate-200">Fourier Neural Operator (FNO)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Training Telemetry:</span>
                <span className="text-slate-200">12.4M Sensor Hours</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">False Positive Rate:</span>
                <span className="text-emerald-400 font-bold">&lt; 1.2%</span>
              </div>
            </div>
          </GlassCard>
        </div>
      </div>
    </div>
  );
};
