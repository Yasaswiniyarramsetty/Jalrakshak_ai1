import React, { useState } from 'react';
import { 
  FileText, 
  Download, 
  Printer, 
  Calendar, 
  CheckCircle2, 
  Clock, 
  ShieldCheck, 
  Share2, 
  Filter,
  BarChart2
} from 'lucide-react';
import { GlassCard } from '../common/GlassCard';
import { WaterAuditStats } from '../../types/pipeline';

interface ReportsProps {
  auditStats: WaterAuditStats;
}

export const Reports: React.FC<ReportsProps> = ({ auditStats }) => {
  const [selectedReportType, setSelectedReportType] = useState<string>('daily-scada');
  const [isExporting, setIsExporting] = useState<boolean>(false);

  const handleExport = (format: 'PDF' | 'CSV') => {
    setIsExporting(true);
    setTimeout(() => {
      setIsExporting(false);
      alert(`Report successfully compiled and downloaded: JalRakshak_Water_Audit_${Date.now()}.${format.toLowerCase()}`);
    }, 1200);
  };

  const reportsList = [
    {
      id: 'daily-scada',
      title: 'Daily Municipal SCADA & Telemetry Executive Digest',
      date: '09 Sep 2026',
      period: '24 Hours',
      classification: 'OFFICIAL USE ONLY',
      status: 'VERIFIED',
      summary: 'Aggregated 24h hydraulic pressure gradients, pump station energy metrics, water loss rate (7.2%), and autonomous throttling log.'
    },
    {
      id: 'monthly-nrw',
      title: 'Monthly IWA Non-Revenue Water (NRW) Balance Report',
      date: '01 Sep 2026',
      period: 'August 2026',
      classification: 'PUBLIC COMPLIANCE',
      status: 'VERIFIED',
      summary: 'Verified 4,280,500 m³ system input vs 3,972,304 m³ billed consumption. Physical loss avoided: 142,680 m³ (₹2.85 Crore saved).'
    },
    {
      id: 'cwc-compliance',
      title: 'Central Water Board Regulatory Quality & Pressure Standard',
      date: '28 Aug 2026',
      period: 'Q2 FY26',
      classification: 'STATUTORY AUDIT',
      status: 'VERIFIED',
      summary: '100% compliance with CPHEEO potable drinking water pressure minimums (2.0 Bar at consumer tap) and residual chlorine thresholds.'
    },
    {
      id: 'incident-postmortem',
      title: 'Post-Mortem: Sector SIS-02 Sub-surface Acoustic Rupture',
      date: '15 Aug 2026',
      period: 'Incident INC-0882',
      classification: 'ENGINEERING REVIEW',
      status: 'RESOLVED',
      summary: 'Root cause analysis of cyclic water hammer failure on 450mm ductile iron trunk line. Autonomous damping prevented 400kL loss.'
    }
  ];

  const activeReport = reportsList.find((r) => r.id === selectedReportType) || reportsList[0];

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Top Header */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-navy-900/90 via-navy-850/90 to-cyan-950/40 border border-cyan-500/20 backdrop-blur-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2 py-0.5 rounded text-[11px] font-mono font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-400/30">
              AUDIT & COMPLIANCE OFFICE
            </span>
            <span className="text-xs font-mono text-emerald-400">
              CPHEEO / CWC STANDARDS COMPLIANT
            </span>
          </div>
          <h2 className="text-2xl font-bold font-display text-white">
            Water Utility Audits & Executive Reporting
          </h2>
          <p className="text-xs text-slate-300 mt-1 max-w-2xl">
            Automated generation of statutory water balance audits, incident post-mortems, physical loss valuations, and engineering maintenance archives.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => handleExport('PDF')}
            disabled={isExporting}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-navy-950 font-semibold text-xs font-mono uppercase tracking-wider transition-all shadow-glow-cyan"
          >
            <Download className="w-4 h-4" />
            <span>{isExporting ? 'Generating...' : 'Export Formal PDF'}</span>
          </button>
          <button
            onClick={() => handleExport('CSV')}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-navy-800 hover:bg-navy-700 text-slate-300 border border-slate-700 font-mono text-xs uppercase transition-colors"
          >
            <Printer className="w-4 h-4" />
            <span>Raw CSV</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Available Reports Directory & Document Previewer */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 1 Col: Reports Library */}
        <div className="space-y-4">
          <GlassCard
            title="Generated Audit Documents"
            subtitle="Select a dossier to preview"
          >
            <div className="space-y-2.5">
              {reportsList.map((rep) => {
                const isSelected = selectedReportType === rep.id;

                return (
                  <div
                    key={rep.id}
                    onClick={() => setSelectedReportType(rep.id)}
                    className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-navy-850 border-cyan-400/50 shadow-glow-cyan'
                        : 'bg-navy-950/60 border-cyan-500/10 hover:border-cyan-500/30'
                    }`}
                  >
                    <div className="flex items-center justify-between text-[10px] font-mono text-slate-400 mb-1">
                      <span>{rep.period}</span>
                      <span className="text-emerald-400 font-bold">{rep.status}</span>
                    </div>
                    <h4 className="font-display font-semibold text-xs text-white line-clamp-2">
                      {rep.title}
                    </h4>
                    <p className="text-[11px] text-slate-400 mt-1 line-clamp-2 font-sans">
                      {rep.summary}
                    </p>
                  </div>
                );
              })}
            </div>
          </GlassCard>

          {/* Compliance Checklist */}
          <GlassCard title="Statutory Water Standards">
            <div className="space-y-2.5 font-mono text-xs text-slate-300">
              <div className="p-2 rounded bg-navy-950/70 border border-cyan-500/10 flex justify-between items-center">
                <span>Consumer Tap Pressure (&gt;2.0 Bar):</span>
                <span className="text-emerald-400 font-bold flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> 99.4%
                </span>
              </div>
              <div className="p-2 rounded bg-navy-950/70 border border-cyan-500/10 flex justify-between items-center">
                <span>Residual Chlorine (&gt;0.5 mg/L):</span>
                <span className="text-emerald-400 font-bold flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> 98.8%
                </span>
              </div>
              <div className="p-2 rounded bg-navy-950/70 border border-cyan-500/10 flex justify-between items-center">
                <span>Total NRW Loss Target (&lt;10%):</span>
                <span className="text-emerald-400 font-bold flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> 7.2% (Passed)
                </span>
              </div>
              <div className="p-2 rounded bg-navy-950/70 border border-cyan-500/10 flex justify-between items-center">
                <span>Emergency Crew Dispatch Time (&lt;25m):</span>
                <span className="text-emerald-400 font-bold flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> 16.4m Avg
                </span>
              </div>
            </div>
          </GlassCard>
        </div>

        {/* Right 2 Cols: Document Sheet Preview */}
        <div className="lg:col-span-2">
          <GlassCard
            title="Dossier Document Sheet Preview"
            subtitle={`Doc ID: ${activeReport.id.toUpperCase()} • Generated: ${activeReport.date}`}
            glow="cyan"
          >
            <div className="p-6 rounded-xl bg-navy-950 border border-cyan-500/20 text-slate-200 font-sans space-y-6">
              {/* Report Header Letterhead */}
              <div className="border-b border-cyan-500/20 pb-4 flex items-start justify-between">
                <div>
                  <div className="text-xs font-mono font-bold text-cyan-400 tracking-wider">
                    JALRAKSHAK AI COMMAND CENTER • MUNICIPAL WATER BOARD
                  </div>
                  <h3 className="text-lg font-bold font-display text-white mt-1">
                    {activeReport.title}
                  </h3>
                  <div className="flex items-center gap-3 text-xs font-mono text-slate-400 mt-1">
                    <span>PERIOD: {activeReport.period}</span>
                    <span>•</span>
                    <span>SECURITY: {activeReport.classification}</span>
                  </div>
                </div>

                <div className="text-right font-mono text-xs text-slate-400">
                  <div className="text-cyan-300 font-bold">DIGITALLY CERTIFIED</div>
                  <div>HASH: #A9F-2026</div>
                </div>
              </div>

              {/* Executive Summary Section */}
              <div className="space-y-2">
                <h4 className="text-xs font-mono font-bold text-cyan-400 uppercase tracking-wider">
                  1. Executive Briefing & Hydraulic Performance
                </h4>
                <p className="text-xs text-slate-300 leading-relaxed">
                  During the monitored window, the metropolitan pipeline transmission grid maintained an average hydraulic pressure of 4.25 Bar across 842.5 km of underground mains. Total system input volume was recorded at {auditStats.totalSuppliedM3.toLocaleString()} m³, with Non-Revenue Water restricted to 7.2% ({auditStats.nonRevenueWaterM3.toLocaleString()} m³), outperforming municipal statutory target requirements.
                </p>
              </div>

              {/* Metrics Table */}
              <div className="space-y-2">
                <h4 className="text-xs font-mono font-bold text-cyan-400 uppercase tracking-wider">
                  2. Key Telemetry & Conservation Yield
                </h4>
                <div className="border border-cyan-500/20 rounded-xl overflow-hidden font-mono text-xs">
                  <div className="grid grid-cols-3 bg-navy-900 p-2.5 font-bold text-cyan-300 border-b border-cyan-500/20">
                    <span>PARAMETER</span>
                    <span>RECORDED VALUE</span>
                    <span>STATUS / BENCHMARK</span>
                  </div>
                  <div className="grid grid-cols-3 p-2.5 border-b border-slate-800 text-slate-300">
                    <span>Gross Potable Supply</span>
                    <span>{auditStats.totalSuppliedM3.toLocaleString()} m³</span>
                    <span className="text-emerald-400">100% Demand Met</span>
                  </div>
                  <div className="grid grid-cols-3 p-2.5 border-b border-slate-800 text-slate-300">
                    <span>Non-Revenue Water</span>
                    <span>7.2% ({auditStats.nonRevenueWaterM3.toLocaleString()} m³)</span>
                    <span className="text-emerald-400">&lt; 10% Statutory Target</span>
                  </div>
                  <div className="grid grid-cols-3 p-2.5 border-b border-slate-800 text-slate-300">
                    <span>Acoustic Leaks Prevented</span>
                    <span>{auditStats.acousticLeaksFound} Ruptures Preempted</span>
                    <span className="text-cyan-300">Zero Unplanned Outages</span>
                  </div>
                  <div className="grid grid-cols-3 p-2.5 text-slate-300">
                    <span>Monetary Value Preserved</span>
                    <span>₹{(auditStats.costSavedInr / 10000000).toFixed(2)} Crore</span>
                    <span className="text-emerald-400">Recouped via Varuna AI</span>
                  </div>
                </div>
              </div>

              {/* Signatures */}
              <div className="border-t border-cyan-500/20 pt-4 flex items-center justify-between text-xs font-mono text-slate-400">
                <div>
                  <span className="block text-white font-semibold">Chief Hydro-Informatics Engineer</span>
                  <span>Supervisory Control & Data Acquisition</span>
                </div>
                <div className="text-right">
                  <span className="block text-cyan-300 font-semibold">Varuna Autonomous AI Core</span>
                  <span>Autonomous Co-Pilot Verification Signed</span>
                </div>
              </div>
            </div>
          </GlassCard>
        </div>
      </div>
    </div>
  );
};
