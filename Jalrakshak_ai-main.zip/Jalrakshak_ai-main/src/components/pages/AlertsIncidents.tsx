import React, { useState } from 'react';
import { 
  AlertTriangle, 
  ShieldAlert, 
  Clock, 
  Truck, 
  CheckCircle2, 
  Sliders, 
  Send, 
  Layers, 
  Filter,
  ArrowRight,
  Sparkles,
  X
} from 'lucide-react';
import { GlassCard } from '../common/GlassCard';
import { SeverityBadge } from '../common/Badge';
import { Modal } from '../common/Modal';
import { Incident, Severity } from '../../types/pipeline';

interface AlertsIncidentsProps {
  incidents: Incident[];
  onAcknowledge: (id: string) => void;
  onDispatchCrew: (id: string, crewName: string) => void;
  onResolve: (id: string) => void;
}

export const AlertsIncidents: React.FC<AlertsIncidentsProps> = ({
  incidents,
  onAcknowledge,
  onDispatchCrew,
  onResolve,
}) => {
  const [selectedIncident, setSelectedIncident] = useState<Incident | null>(null);
  const [filterSeverity, setFilterSeverity] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [dispatchModalOpen, setDispatchModalOpen] = useState<boolean>(false);
  const [selectedCrew, setSelectedCrew] = useState<string>('Rapid Response Unit 4 (Excavator & Trench Shoring)');

  const filteredIncidents = incidents.filter((inc) => {
    if (filterSeverity !== 'all' && inc.severity !== filterSeverity) return false;
    if (filterStatus !== 'all' && inc.status !== filterStatus) return false;
    return true;
  });

  const handleOpenDispatch = (incident: Incident) => {
    setSelectedIncident(incident);
    setDispatchModalOpen(true);
  };

  const handleConfirmDispatch = () => {
    if (selectedIncident) {
      onDispatchCrew(selectedIncident.id, selectedCrew);
      setDispatchModalOpen(false);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Top Filter and Severity Triage Summary Bar */}
      <div className="p-4 rounded-xl bg-navy-900/80 border border-cyan-500/20 backdrop-blur-md flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-2 text-xs font-mono text-cyan-300">
            <Filter className="w-4 h-4 text-cyan-400" />
            <span>INCIDENT FILTERS:</span>
          </div>

          <select
            value={filterSeverity}
            onChange={(e) => setFilterSeverity(e.target.value)}
            className="bg-navy-950 border border-cyan-500/20 rounded-lg px-3 py-1.5 text-xs font-mono text-slate-200 focus:outline-none"
          >
            <option value="all">All Severities</option>
            <option value="P1_CRITICAL">P1 Critical</option>
            <option value="P2_HIGH">P2 High</option>
            <option value="P3_MODERATE">P3 Moderate</option>
            <option value="P4_LOW">P4 Low</option>
          </select>

          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="bg-navy-950 border border-cyan-500/20 rounded-lg px-3 py-1.5 text-xs font-mono text-slate-200 focus:outline-none"
          >
            <option value="all">All Statuses</option>
            <option value="ACTIVE">Active Alarms</option>
            <option value="ACKNOWLEDGED">Acknowledged</option>
            <option value="CREW_DISPATCHED">Crew Dispatched</option>
            <option value="RESOLVED">Resolved</option>
          </select>
        </div>

        <div className="flex items-center gap-4 text-xs font-mono">
          <span className="text-slate-400">Total Filtered: <strong className="text-white">{filteredIncidents.length}</strong></span>
          <span className="text-rose-400 font-bold">
            {incidents.filter((i) => i.severity === 'P1_CRITICAL' && i.status !== 'RESOLVED').length} P1 Active
          </span>
        </div>
      </div>

      {/* Main Grid: Incident Cards & Detailed Incident Room */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Incident Feed */}
        <div className="lg:col-span-2 space-y-4">
          {filteredIncidents.map((incident) => {
            const isCritical = incident.severity === 'P1_CRITICAL';
            const isResolved = incident.status === 'RESOLVED';

            return (
              <div
                key={incident.id}
                className={`p-4 rounded-xl border transition-all ${
                  isResolved
                    ? 'bg-navy-900/40 border-slate-800 opacity-70'
                    : isCritical
                    ? 'bg-navy-900/80 border-rose-500/40 shadow-glow-red'
                    : 'bg-navy-900/70 border-cyan-500/20'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2 flex-wrap">
                    <SeverityBadge severity={incident.severity} />
                    <span className="text-xs font-mono text-cyan-300 font-bold">{incident.code}</span>
                    <span className="text-xs text-slate-400">• {incident.timestamp}</span>
                    <span className="text-xs font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                      {incident.zoneName}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span
                      className={`text-xs font-mono font-bold px-2 py-0.5 rounded uppercase ${
                        incident.status === 'RESOLVED'
                          ? 'bg-emerald-500/20 text-emerald-300'
                          : incident.status === 'CREW_DISPATCHED'
                          ? 'bg-sky-500/20 text-sky-300'
                          : incident.status === 'ACKNOWLEDGED'
                          ? 'bg-amber-500/20 text-amber-300'
                          : 'bg-rose-500/20 text-rose-300 animate-pulse'
                      }`}
                    >
                      {incident.status.replace('_', ' ')}
                    </span>
                  </div>
                </div>

                <h3 className="font-display font-semibold text-base text-white">
                  {incident.title}
                </h3>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 my-3 text-xs font-mono text-slate-300">
                  <div className="p-2 rounded bg-navy-950/70 border border-cyan-500/10">
                    <span className="text-[10px] text-slate-400 block">Estimated Loss Rate</span>
                    <strong className="text-rose-400">{incident.estimatedLossRateLpm} L/min</strong>
                  </div>
                  <div className="p-2 rounded bg-navy-950/70 border border-cyan-500/10">
                    <span className="text-[10px] text-slate-400 block">AI Confidence Score</span>
                    <strong className="text-cyan-300">{incident.aiConfidence}%</strong>
                  </div>
                  <div className="p-2 rounded bg-navy-950/70 border border-cyan-500/10 col-span-2 sm:col-span-1">
                    <span className="text-[10px] text-slate-400 block">Assigned Crew</span>
                    <strong className="text-slate-200 truncate block">
                      {incident.assignedCrew || 'Unassigned'}
                    </strong>
                  </div>
                </div>

                {/* Actions history log */}
                <div className="space-y-1 mb-4">
                  <span className="text-[10px] font-mono uppercase text-slate-400 tracking-wider">
                    Automated Actions Audit Trail:
                  </span>
                  {incident.actionsTaken.map((act, i) => (
                    <div key={i} className="text-xs text-slate-300 flex items-start gap-1.5">
                      <span className="text-cyan-400 font-mono">•</span>
                      <span>{act}</span>
                    </div>
                  ))}
                </div>

                {/* Operator Actions Bar */}
                <div className="flex items-center justify-end gap-2 pt-2 border-t border-cyan-500/10">
                  {incident.status === 'ACTIVE' && (
                    <button
                      onClick={() => onAcknowledge(incident.id)}
                      className="px-3 py-1.5 rounded-lg text-xs font-mono font-semibold bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 transition-colors"
                    >
                      Acknowledge Alarm
                    </button>
                  )}

                  {incident.status !== 'RESOLVED' && (
                    <button
                      onClick={() => handleOpenDispatch(incident)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono font-semibold bg-sky-500/20 hover:bg-sky-500/30 text-sky-300 border border-sky-500/40 transition-colors"
                    >
                      <Truck className="w-3.5 h-3.5" />
                      <span>Dispatch Field Crew</span>
                    </button>
                  )}

                  {incident.status !== 'RESOLVED' && (
                    <button
                      onClick={() => onResolve(incident.id)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono font-semibold bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 transition-colors"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Mark Restored & Resolved</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Right 1 Col: Standard Operating Procedure (SOP) & Crew Status */}
        <div className="space-y-4">
          <GlassCard
            title="Emergency Response Protocol (SOP)"
            subtitle="Central Water SCADA Directive for Pipeline Fractures"
            glow="red"
          >
            <div className="space-y-3 font-mono text-xs text-slate-300">
              <div className="p-3 rounded-lg bg-navy-950/70 border border-cyan-500/15">
                <span className="text-cyan-400 font-bold block mb-1">Step 1: Automated Valve Throttling</span>
                <p className="text-slate-300 font-sans">
                  Varuna AI triggers upstream PRV damping to 25-35% within 180ms to isolate surge and prevent secondary cavitation bursts.
                </p>
              </div>

              <div className="p-3 rounded-lg bg-navy-950/70 border border-cyan-500/15">
                <span className="text-sky-400 font-bold block mb-1">Step 2: Acoustic Correlation Pinpointing</span>
                <p className="text-slate-300 font-sans">
                  Ground crew acoustic correlation squad deploys pipe microphones to confirm breach location within ±1.5m accuracy.
                </p>
              </div>

              <div className="p-3 rounded-lg bg-navy-950/70 border border-cyan-500/15">
                <span className="text-amber-400 font-bold block mb-1">Step 3: Rapid Excavation & Clamp Sleeve</span>
                <p className="text-slate-300 font-sans">
                  Targeted vacuum suction excavation or trench box placement with stainless steel repair sleeve installation.
                </p>
              </div>

              <div className="p-3 rounded-lg bg-navy-950/70 border border-cyan-500/15">
                <span className="text-emerald-400 font-bold block mb-1">Step 4: Hydrostatic Recharge & Water Quality</span>
                <p className="text-slate-300 font-sans">
                  Gradual line pressurization, turbidity and residual chlorine check before resumption of municipal supply.
                </p>
              </div>
            </div>
          </GlassCard>

          <GlassCard title="Field Squads on Standby">
            <div className="space-y-2 text-xs font-mono text-slate-300">
              <div className="p-2.5 rounded-lg bg-navy-950/70 border border-cyan-500/15 flex justify-between">
                <div>
                  <span className="text-white font-bold block">Rapid Response Unit 4</span>
                  <span className="text-[10px] text-slate-400">Heavy Excavation & Sleeve Clamps</span>
                </div>
                <span className="text-emerald-400 font-bold">AVAILABLE</span>
              </div>

              <div className="p-2.5 rounded-lg bg-navy-950/70 border border-cyan-500/15 flex justify-between">
                <div>
                  <span className="text-white font-bold block">Acoustic Correlation Squad 2</span>
                  <span className="text-[10px] text-slate-400">Ground Microphones & Hydrophones</span>
                </div>
                <span className="text-cyan-300 font-bold">DEPLOYED</span>
              </div>

              <div className="p-2.5 rounded-lg bg-navy-950/70 border border-cyan-500/15 flex justify-between">
                <div>
                  <span className="text-white font-bold block">Valve Isolation Team 1</span>
                  <span className="text-[10px] text-slate-400">Motorized Actuator Calibration</span>
                </div>
                <span className="text-emerald-400 font-bold">STANDBY</span>
              </div>
            </div>
          </GlassCard>
        </div>
      </div>

      {/* Dispatch Modal Dialog */}
      <Modal
        isOpen={dispatchModalOpen}
        onClose={() => setDispatchModalOpen(false)}
        title="Dispatch Rapid Repair Field Squad"
        subtitle={`Incident: ${selectedIncident?.code} • ${selectedIncident?.zoneName}`}
      >
        <div className="space-y-4">
          <div className="p-3 rounded-xl bg-navy-950/80 border border-cyan-500/20 text-xs font-mono text-slate-300 space-y-1">
            <div className="flex justify-between">
              <span className="text-slate-400">Breach Location:</span>
              <span className="text-white font-bold">{selectedIncident?.title}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Current Loss Rate:</span>
              <span className="text-rose-400 font-bold">{selectedIncident?.estimatedLossRateLpm} L/min</span>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-mono text-slate-300 block">
              SELECT RESPONSE UNIT:
            </label>
            <select
              value={selectedCrew}
              onChange={(e) => setSelectedCrew(e.target.value)}
              className="w-full bg-navy-950 border border-cyan-500/30 rounded-xl px-3 py-2 text-xs font-mono text-cyan-300 focus:outline-none"
            >
              <option value="Rapid Response Unit 4 (Excavator & Trench Shoring)">
                Rapid Response Unit 4 (Excavator & Trench Shoring) — ETA: 14 mins
              </option>
              <option value="Acoustic Correlation Squad 2 (Ground Microphones)">
                Acoustic Correlation Squad 2 (Ground Microphones) — ETA: 22 mins
              </option>
              <option value="Valve Isolation Team 1 (Emergency Throttling)">
                Valve Isolation Team 1 (Emergency Throttling) — ETA: 8 mins
              </option>
            </select>
          </div>

          <div className="p-3 rounded-xl bg-sky-950/30 border border-sky-400/30 text-xs text-sky-200">
            Dispatching will generate a digital job order, alert the municipal emergency desk, and transmit GPS coordinates directly to the field squad rugged tablet.
          </div>

          <div className="flex justify-end gap-3 pt-3 border-t border-cyan-500/20">
            <button
              onClick={() => setDispatchModalOpen(false)}
              className="px-4 py-2 rounded-xl text-xs font-mono text-slate-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              onClick={handleConfirmDispatch}
              className="px-5 py-2 rounded-xl text-xs font-mono font-bold bg-cyan-500 hover:bg-cyan-400 text-navy-950 shadow-glow-cyan transition-all"
            >
              Confirm Squad Dispatch
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
