import React, { useState } from 'react';
import { useTelemetry } from './hooks/useTelemetry';
import { DashboardLayout } from './components/layout/DashboardLayout';
import { PageId, SensorNode } from './types/pipeline';

// Pages
import { CommandCenter } from './components/pages/CommandCenter';
import { PipelineNetwork } from './components/pages/PipelineNetwork';
import { LiveMonitoring } from './components/pages/LiveMonitoring';
import { AiPredictions } from './components/pages/AiPredictions';
import { DigitalTwin } from './components/pages/DigitalTwin';
import { WaterLossAnalysis } from './components/pages/WaterLossAnalysis';
import { AlertsIncidents } from './components/pages/AlertsIncidents';
import { AiAgent } from './components/pages/AiAgent';
import { Reports } from './components/pages/Reports';
import { Settings } from './components/pages/Settings';

export function App() {
  const [currentPage, setCurrentPage] = useState<PageId>('command-center');
  const [selectedNode, setSelectedNode] = useState<SensorNode | null>(null);

  const {
    zones,
    nodes,
    incidents,
    predictions,
    auditStats,
    agentLogs,
    selectedZone,
    setSelectedZone,
    emergencyMode,
    setEmergencyMode,
    isSimulating,
    setIsSimulating,
    telemetryHistory,
    acknowledgeIncident,
    dispatchCrew,
    resolveIncident,
    injectSimulatedSurge,
    sendAgentCommand,
  } = useTelemetry();

  // Navigation helper with optional node inspection
  const handleSelectNode = (node: SensorNode | null) => {
    setSelectedNode(node);
    if (node && currentPage === 'command-center') {
      setCurrentPage('pipeline-network');
    }
  };

  const activeSensorsCount = nodes.filter((n) => n.status === 'ONLINE').length;
  const criticalAlertsCount = incidents.filter(
    (i) => i.severity === 'P1_CRITICAL' && i.status !== 'RESOLVED'
  ).length;
  const avgPressure =
    nodes.reduce((acc, n) => acc + n.readings.pressureBar, 0) / (nodes.length || 1);
  const currentLossRateLpm = incidents
    .filter((i) => i.status !== 'RESOLVED')
    .reduce((acc, i) => acc + i.estimatedLossRateLpm, 0);

  return (
    <DashboardLayout
      currentPage={currentPage}
      onPageChange={setCurrentPage}
      zones={zones}
      selectedZone={selectedZone}
      onZoneSelect={setSelectedZone}
      emergencyMode={emergencyMode}
      onToggleEmergency={() => setEmergencyMode(!emergencyMode)}
      activeSensorsCount={activeSensorsCount}
      totalSensorsCount={nodes.length}
      criticalAlertsCount={criticalAlertsCount}
      avgPressure={avgPressure}
      currentLossRateLpm={currentLossRateLpm}
    >
      {currentPage === 'command-center' && (
        <CommandCenter
          zones={zones}
          nodes={nodes}
          incidents={incidents}
          predictions={predictions}
          onNavigate={setCurrentPage}
          onSelectNode={handleSelectNode}
          onAcknowledgeIncident={acknowledgeIncident}
        />
      )}

      {currentPage === 'pipeline-network' && (
        <PipelineNetwork
          zones={zones}
          nodes={nodes}
          selectedNode={selectedNode}
          onSelectNode={handleSelectNode}
        />
      )}

      {currentPage === 'live-monitoring' && (
        <LiveMonitoring
          nodes={nodes}
          telemetryHistory={telemetryHistory}
          isSimulating={isSimulating}
          onToggleSimulating={() => setIsSimulating(!isSimulating)}
        />
      )}

      {currentPage === 'ai-predictions' && (
        <AiPredictions predictions={predictions} />
      )}

      {currentPage === 'digital-twin' && (
        <DigitalTwin
          nodes={nodes}
          onInjectSurge={injectSimulatedSurge}
        />
      )}

      {currentPage === 'water-loss' && (
        <WaterLossAnalysis auditStats={auditStats} />
      )}

      {currentPage === 'alerts-incidents' && (
        <AlertsIncidents
          incidents={incidents}
          onAcknowledge={acknowledgeIncident}
          onDispatchCrew={dispatchCrew}
          onResolve={resolveIncident}
        />
      )}

      {currentPage === 'ai-agent' && (
        <AiAgent
          agentLogs={agentLogs}
          onSendCommand={sendAgentCommand}
        />
      )}

      {currentPage === 'reports' && (
        <Reports auditStats={auditStats} />
      )}

      {currentPage === 'settings' && (
        <Settings />
      )}
    </DashboardLayout>
  );
}

export default App;
