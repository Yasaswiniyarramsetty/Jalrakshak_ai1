import { useState, useEffect, useCallback } from 'react';
import { 
  Zone, 
  SensorNode, 
  Incident, 
  AiPrediction, 
  WaterAuditStats, 
  AgentLog, 
  TelemetryPoint 
} from '../types/pipeline';
import { 
  INITIAL_ZONES, 
  INITIAL_NODES, 
  INITIAL_INCIDENTS, 
  INITIAL_PREDICTIONS, 
  INITIAL_AUDIT_STATS, 
  INITIAL_AGENT_LOGS 
} from '../data/mockData';

export function useTelemetry() {
  const [zones] = useState<Zone[]>(INITIAL_ZONES);
  const [nodes, setNodes] = useState<SensorNode[]>(INITIAL_NODES);
  const [incidents, setIncidents] = useState<Incident[]>(INITIAL_INCIDENTS);
  const [predictions, setPredictions] = useState<AiPrediction[]>(INITIAL_PREDICTIONS);
  const [auditStats, setAuditStats] = useState<WaterAuditStats>(INITIAL_AUDIT_STATS);
  const [agentLogs, setAgentLogs] = useState<AgentLog[]>(INITIAL_AGENT_LOGS);
  const [selectedZone, setSelectedZone] = useState<string>('all');
  const [emergencyMode, setEmergencyMode] = useState<boolean>(false);
  const [isSimulating, setIsSimulating] = useState<boolean>(true);
  
  // Real-time rolling chart telemetry data
  const [telemetryHistory, setTelemetryHistory] = useState<TelemetryPoint[]>(() => {
    const points: TelemetryPoint[] = [];
    const now = new Date();
    for (let i = 20; i >= 0; i--) {
      const t = new Date(now.getTime() - i * 3000);
      const timeStr = t.toTimeString().split(' ')[0];
      points.push({
        time: timeStr,
        pressure: Number((4.1 + Math.sin(i * 0.4) * 0.35 + (Math.random() * 0.1 - 0.05)).toFixed(2)),
        flow: Number((180 + Math.cos(i * 0.3) * 25 + (Math.random() * 5 - 2.5)).toFixed(1)),
        acoustic: Number((24 + Math.sin(i * 0.5) * 8 + (Math.random() * 3)).toFixed(1)),
        ph: Number((7.32 + Math.sin(i * 0.2) * 0.08).toFixed(2))
      });
    }
    return points;
  });

  // Background real-time IoT packet tick
  useEffect(() => {
    if (!isSimulating) return;

    const interval = setInterval(() => {
      const now = new Date();
      const timeStr = now.toTimeString().split(' ')[0];

      // Jitter nodes slightly to simulate live IoT sensors
      setNodes((prevNodes) =>
        prevNodes.map((node) => {
          const pJitter = (Math.random() - 0.5) * 0.06;
          const fJitter = (Math.random() - 0.5) * 1.8;
          const aJitter = (Math.random() - 0.5) * 0.8;
          
          return {
            ...node,
            readings: {
              ...node.readings,
              pressureBar: Math.max(0.5, Number((node.readings.pressureBar + pJitter).toFixed(2))),
              flowLps: Math.max(0, Number((node.readings.flowLps + fJitter).toFixed(1))),
              acousticDb: Math.max(5, Number((node.readings.acousticDb + aJitter).toFixed(1)))
            },
            lastTelemetryTime: 'Just now'
          };
        })
      );

      // Append new rolling chart telemetry point
      setTelemetryHistory((prev) => {
        const last = prev[prev.length - 1];
        const newPressure = Number((Math.max(2.0, Math.min(6.5, last.pressure + (Math.random() - 0.49) * 0.12))).toFixed(2));
        const newFlow = Number((Math.max(120, Math.min(260, last.flow + (Math.random() - 0.49) * 4))).toFixed(1));
        const newAcoustic = Number((Math.max(10, Math.min(65, last.acoustic + (Math.random() - 0.48) * 2))).toFixed(1));
        const newPh = Number((Math.max(6.8, Math.min(7.9, last.ph + (Math.random() - 0.5) * 0.02))).toFixed(2));

        const updated = [...prev.slice(1), {
          time: timeStr,
          pressure: newPressure,
          flow: newFlow,
          acoustic: newAcoustic,
          ph: newPh
        }];
        return updated;
      });
    }, 2500);

    return () => clearInterval(interval);
  }, [isSimulating]);

  // Actions
  const acknowledgeIncident = useCallback((id: string) => {
    setIncidents((prev) =>
      prev.map((inc) =>
        inc.id === id ? { ...inc, status: 'ACKNOWLEDGED' as const, actionsTaken: [...inc.actionsTaken, 'Acknowledged by Central Command Officer'] } : inc
      )
    );
  }, []);

  const dispatchCrew = useCallback((id: string, crewName: string) => {
    setIncidents((prev) =>
      prev.map((inc) =>
        inc.id === id ? { 
          ...inc, 
          status: 'CREW_DISPATCHED' as const, 
          assignedCrew: crewName,
          actionsTaken: [...inc.actionsTaken, `Crew '${crewName}' deployed via automated dispatch dispatch ticket.`]
        } : inc
      )
    );
  }, []);

  const resolveIncident = useCallback((id: string) => {
    setIncidents((prev) =>
      prev.map((inc) =>
        inc.id === id ? { 
          ...inc, 
          status: 'RESOLVED' as const, 
          actionsTaken: [...inc.actionsTaken, 'Hydrostatic pressure restored. Sensor verification normal. Incident closed.']
        } : inc
      )
    );
  }, []);

  // Digital Twin Simulation: Inject simulated pressure wave / rupture
  const injectSimulatedSurge = useCallback((nodeId: string, surgeBar: number) => {
    setNodes((prev) =>
      prev.map((node) => {
        if (node.id === nodeId) {
          return {
            ...node,
            status: surgeBar > 3 ? 'DEGRADED' : node.status,
            readings: {
              ...node.readings,
              pressureBar: Number((node.readings.pressureBar + surgeBar).toFixed(2)),
              acousticDb: Number((node.readings.acousticDb + surgeBar * 6).toFixed(1))
            }
          };
        }
        return node;
      })
    );

    // Add an autonomous agent log entry reacting to this
    const nowStr = new Date().toTimeString().split(' ')[0];
    const newLog: AgentLog = {
      id: `log-${Date.now()}`,
      timestamp: nowStr,
      step: 'OBSERVE',
      targetNodeOrValve: `Node #${nodeId}`,
      description: `Injected telemetry test pulse of +${surgeBar} Bar detected. Varuna AI evaluating transient attenuation threshold.`,
      confidence: 99.4,
      automatedActionApplied: true
    };
    setAgentLogs((prev) => [newLog, ...prev]);
  }, []);

  // AI Agent operator interactions
  const sendAgentCommand = useCallback((operatorPrompt: string): string => {
    const promptLower = operatorPrompt.toLowerCase();
    const nowStr = new Date().toTimeString().split(' ')[0];
    let responseText = '';

    if (promptLower.includes('south') || promptLower.includes('burst') || promptLower.includes('s-02')) {
      responseText = 'VARUNA AI: Critical hydraulic divergence detected at Node S-02. Upstream PRV-09 throttled to 38% capacity. Pressure gradient stabilized from 6.8 Bar to 4.2 Bar. Recommended action: Maintain isolation until Rapid Response Unit 4 completes collar clamp installation.';
    } else if (promptLower.includes('pressure') || promptLower.includes('transient') || promptLower.includes('hammer')) {
      responseText = 'VARUNA AI: Hydraulic transient risk is currently concentrated in Sector SIS-02 (Industrial) due to sudden valve closures. Transient dampening bladders are at 84% absorption efficiency. No structural burst expected in the next 6 hours.';
    } else if (promptLower.includes('nrw') || promptLower.includes('loss') || promptLower.includes('water')) {
      responseText = `VARUNA AI: Current Non-Revenue Water rate is 7.2% (${auditStats.nonRevenueWaterM3.toLocaleString()} m³), outperforming the municipal benchmark of 15.0%. Acoustic hydrophones have preempted ₹${(auditStats.costSavedInr / 10000000).toFixed(2)} Crore in potential subterranean erosion losses.`;
    } else {
      responseText = `VARUNA AI: Telemetry mesh operational across 4 sectors with 98.4% packet integrity. No unacknowledged P1 events detected outside of Zone SIS-02. All autonomous throttling valves are responding within nominal 180ms latency.`;
    }

    const newLog: AgentLog = {
      id: `log-${Date.now()}`,
      timestamp: nowStr,
      step: 'ACT',
      targetNodeOrValve: 'Varuna AI Agent Core',
      description: `Operator Query: "${operatorPrompt}" -> Response synthesized & telemetry cross-checked.`,
      confidence: 98.6,
      automatedActionApplied: true
    };
    setAgentLogs((prev) => [newLog, ...prev]);

    return responseText;
  }, [auditStats]);

  return {
    zones,
    nodes,
    incidents,
    predictions,
    auditStats,
    agentLogs,
    selectedZone,
    setSelectedZone,
    emergencyMode,
    setEmergencyMode,
    isSimulating,
    setIsSimulating,
    telemetryHistory,
    acknowledgeIncident,
    dispatchCrew,
    resolveIncident,
    injectSimulatedSurge,
    sendAgentCommand
  };
}
