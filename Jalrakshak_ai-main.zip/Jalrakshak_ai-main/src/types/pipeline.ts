export type PageId =
  | 'command-center'
  | 'pipeline-network'
  | 'live-monitoring'
  | 'ai-predictions'
  | 'digital-twin'
  | 'water-loss'
  | 'alerts-incidents'
  | 'ai-agent'
  | 'reports'
  | 'settings';

export type SystemStatus = 'OPTIMAL' | 'ADVISORY' | 'CRITICAL';

export type Severity = 'P1_CRITICAL' | 'P2_HIGH' | 'P3_MODERATE' | 'P4_LOW';

export type SensorType = 'PRESSURE' | 'FLOW' | 'ACOUSTIC' | 'WATER_QUALITY' | 'MULTI';

export type NodeStatus = 'ONLINE' | 'DEGRADED' | 'OFFLINE';

export interface Zone {
  id: string;
  name: string;
  code: string;
  activeLineKm: number;
  nodesCount: number;
  avgPressure: number;
  status: SystemStatus;
  lossRatePercent: number;
  description: string;
}

export interface SensorNode {
  id: string;
  name: string;
  zoneId: string;
  zoneName: string;
  type: SensorType;
  x: number; // percentage coordinate on schematic map
  y: number;
  depthMeters: number;
  pipeDiameterMm: number;
  pipeMaterial: 'Ductile Iron' | 'HDPE' | 'Pre-stressed Concrete' | 'Cast Iron' | 'Mild Steel';
  installationYear: number;
  status: NodeStatus;
  batteryLevel: number; // percentage
  rssi: number; // -dBm
  readings: {
    pressureBar: number;
    flowLps: number;
    acousticDb: number;
    ph: number;
    turbidityNtu: number;
    chlorineMgL: number;
    tempC: number;
  };
  lastTelemetryTime: string;
}

export interface Incident {
  id: string;
  code: string;
  title: string;
  zoneId: string;
  zoneName: string;
  nodeId: string;
  severity: Severity;
  type: 'PIPE_BURST' | 'PRESSURE_TRANSIENT' | 'MICRO_LEAK' | 'SENSOR_ANOMALY' | 'VALVE_FAULT';
  status: 'ACTIVE' | 'ACKNOWLEDGED' | 'CREW_DISPATCHED' | 'RESOLVED';
  timestamp: string;
  estimatedLossRateLpm: number;
  aiConfidence: number;
  assignedCrew?: string;
  actionsTaken: string[];
}

export interface AiPrediction {
  id: string;
  segmentId: string;
  segmentName: string;
  zoneName: string;
  burstRiskScore: number; // 0 - 100
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'EXTREME';
  remainingUsefulLifeMonths: number;
  degradationRatePercent: number;
  transientVulnerability: 'STABLE' | 'ELEVATED' | 'CRITICAL';
  recommendation: string;
  primaryStressFactor: string;
  lastSimulatedHammerBar: number;
}

export interface TelemetryPoint {
  time: string;
  pressure: number;
  flow: number;
  acoustic: number;
  ph: number;
}

export interface AgentLog {
  id: string;
  timestamp: string;
  step: 'OBSERVE' | 'ORIENT' | 'DECIDE' | 'ACT';
  targetNodeOrValve: string;
  description: string;
  confidence: number;
  automatedActionApplied: boolean;
}

export interface WaterAuditStats {
  totalSuppliedM3: number;
  totalBilledM3: number;
  nonRevenueWaterM3: number;
  nrwPercentage: number;
  acousticLeaksFound: number;
  physicalLossSavedM3: number;
  costSavedInr: number; // in INR
}
